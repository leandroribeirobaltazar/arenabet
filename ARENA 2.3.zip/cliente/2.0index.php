<?php
// Inicia a sessão no topo absoluto para evitar falhas de cabeçalho
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

@include_once '../conexao.php';

if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../login.php");
    exit;
}

$usuario_id = $_SESSION['usuario_id'];
$usuario_nome = $_SESSION['usuario_nome'] ?? 'Cliente';
$saldo = 0.00;

// Configura fuso horário oficial de Brasília
date_default_timezone_set('America/Sao_Paulo');

if (isset($pdo)) {
    try {
        $stmt = $pdo->prepare("SELECT saldo, nome FROM usuarios WHERE id = ?");
        $stmt->execute([$usuario_id]);
        $u = $stmt->fetch();
        if ($u) {
            $saldo = $u['saldo'];
            $usuario_nome = $u['nome'];
        }
    } catch (Exception $e) {}
}

// Garante colunas essenciais no banco se não existirem
if (isset($pdo)) {
    try {
        $pdo->exec("ALTER TABLE apostas ADD COLUMN ocultar_cliente TINYINT(1) DEFAULT 0");
    } catch (Exception $e) {}
    try {
        $pdo->exec("ALTER TABLE jogos ADD COLUMN categoria VARCHAR(100) DEFAULT 'Brasileirão'");
    } catch (Exception $e) {}
    try {
        $pdo->exec("ALTER TABLE jogos ADD COLUMN super_odd TINYINT(1) DEFAULT 0");
    } catch (Exception $e) {}
}

// Ocultar aposta do painel do cliente
if (isset($_GET['ocultar_aposta']) && isset($pdo)) {
    $aposta_id = intval($_GET['ocultar_aposta']);
    try {
        $stmt = $pdo->prepare("UPDATE apostas SET ocultar_cliente = 1 WHERE id = ? AND usuario_id = ?");
        $stmt->execute([$aposta_id, $usuario_id]);
    } catch (Exception $e) {}
    header("Location: index.php");
    exit;
}

// TRATAMENTO EXCLUSIVO DE POST PARA APOSTAS (Com validação rígida de horário de Brasília)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fazer_aposta'])) {
    $jogo_id = intval($_POST['jogo_id'] ?? 0);
    $tipo_aposta = $_POST['tipo_aposta'] ?? '';
    $odd = floatval($_POST['odd'] ?? 0);
    $valor_aposta = floatval($_POST['valor_aposta'] ?? 0);

    // Validação de segurança no backend: verifica se o jogo já começou
    $jogo_permitido = true;
    if (isset($pdo)) {
        try {
            $stmtJ = $pdo->prepare("SELECT data_hora, status FROM jogos WHERE id = ?");
            $stmtJ->execute([$jogo_id]);
            $dadosJogo = $stmtJ->fetch();
            if ($dadosJogo) {
                $agora = new DateTime('now', new DateTimeZone('America/Sao_Paulo'));
                $inicioJogo = new DateTime($dadosJogo['data_hora'], new DateTimeZone('America/Sao_Paulo'));
                if ($dadosJogo['status'] !== 'aberto' || $agora >= $inicioJogo) {
                    $jogo_permitido = false;
                }
            } else {
                $jogo_permitido = false;
            }
        } catch (Exception $e) {
            $jogo_permitido = false;
        }
    }

    if (!$jogo_permitido) {
        $_SESSION['toast_erro'] = "Atenção: Este jogo já começou ou está encerrado! Não é permitido realizar apostas após o início da partida.";
    } elseif ($valor_aposta > 0 && $valor_aposta <= $saldo) {
        $possivel_retorno = $valor_aposta * $odd;
        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("INSERT INTO apostas (usuario_id, jogo_id, tipo_aposta, odd, valor, possivel_retorno, status, ocultar_cliente) VALUES (?, ?, ?, ?, ?, ?, 'Pendente', 0)");
            $stmt->execute([$usuario_id, $jogo_id, $tipo_aposta, $odd, $valor_aposta, $possivel_retorno]);

            $stmt = $pdo->prepare("UPDATE usuarios SET saldo = saldo - ? WHERE id = ?");
            $stmt->execute([$valor_aposta, $usuario_id]);

            $pdo->commit();
            $_SESSION['toast_sucesso'] = "Aposta realizada com sucesso! Boa sorte!";
        } catch (Exception $e) {
            $pdo->rollBack();
            $_SESSION['toast_erro'] = "Erro ao registrar aposta: " . $e->getMessage();
        }
    } else {
        $_SESSION['toast_erro'] = "Saldo insuficiente ou valor inválido!";
    }
    header("Location: index.php");
    exit;
}

// TRATAMENTO EXCLUSIVO E RIGOROSO DE POST PARA PIX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['enviar_pix']) && intval($_POST['enviar_pix']) === 1) {
    $valor_deposito = floatval($_POST['valor_deposito'] ?? 0);
    if ($valor_deposito > 0 && isset($pdo)) {
        try {
            $stmt = $pdo->prepare("INSERT INTO depositos_pix (usuario_id, usuario_nome, valor, status) VALUES (?, ?, ?, 'Pendente')");
            $stmt->execute([$usuario_id, $usuario_nome, $valor_deposito]);
            $_SESSION['toast_sucesso'] = "Aviso de pagamento enviado com sucesso! O administrador foi notificado.";
        } catch (Exception $e) {
            $_SESSION['toast_erro'] = "Erro ao registrar aviso: " . $e->getMessage();
        }
    }
    header("Location: index.php");
    exit;
}

// Captura e limpa imediatamente as mensagens da sessão
$toast_sucesso = $_SESSION['toast_sucesso'] ?? '';
unset($_SESSION['toast_sucesso']);

$toast_erro = $_SESSION['toast_erro'] ?? '';
unset($_SESSION['toast_erro']);

$jogos = [];
if (isset($pdo)) {
    try {
        $stmt = $pdo->query("SELECT * FROM jogos WHERE status = 'aberto' ORDER BY data_hora ASC");
        $jogos = $stmt->fetchAll();
    } catch (Exception $e) {}
}

$minhas_apostas = [];
if (isset($pdo)) {
    try {
        $stmt = $pdo->prepare("SELECT a.*, j.time_mandante, j.time_visitante FROM apostas a JOIN jogos j ON a.jogo_id = j.id WHERE a.usuario_id = ? AND a.ocultar_cliente = 0 ORDER BY a.criado_em DESC");
        $stmt->execute([$usuario_id]);
        $minhas_apostas = $stmt->fetchAll();
    } catch (Exception $e) {}
}

$historico_completo = [];
if (isset($pdo)) {
    try {
        $stmt = $pdo->prepare("SELECT a.*, j.time_mandante, j.time_visitante FROM apostas a JOIN jogos j ON a.jogo_id = j.id WHERE a.usuario_id = ? ORDER BY a.criado_em DESC");
        $stmt->execute([$usuario_id]);
        $historico_completo = $stmt->fetchAll();
    } catch (Exception $e) {}
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Escritório Virtual - ArenaBet</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    :root { --neon-green: #00FF66; --bg-dark: #07090e; }
    body { background-color: var(--bg-dark); color: #ffffff; font-family: 'Segoe UI', sans-serif; font-size: 12px; }
    .text-neon { color: var(--neon-green); text-shadow: 0 0 10px rgba(0, 255, 102, 0.35); }
    .bg-neon { background-color: var(--neon-green); color: #000000; }

    /* ANIMAÇÃO E ESTILO DE SUPER ODD (BORDA NEON PULSANTE) */
    @keyframes neonPulse {
      0%, 100% { 
        border-color: rgba(0, 255, 102, 0.4); 
        box-shadow: 0 0 10px rgba(0, 255, 102, 0.2); 
      }
      50% { 
        border-color: rgba(0, 255, 102, 1); 
        box-shadow: 0 0 25px rgba(0, 255, 102, 0.6); 
      }
    }
    .super-odd-card {
      animation: neonPulse 2s infinite ease-in-out;
      border-width: 2px !important;
      position: relative;
    }

    /* ANIMAÇÃO DA BOLINHA VERMELHA PISCANTO (AO VIVO) */
    @keyframes pulseRed {
      0%, 100% { transform: scale(1); opacity: 1; }
      50% { transform: scale(1.3); opacity: 0.4; }
    }
    .live-dot {
      animation: pulseRed 1.2s infinite ease-in-out;
    }

    /* Rolagem suave de categorias no celular */
    .categorias-scroll {
      display: flex;
      gap: 8px;
      overflow-x: auto;
      white-space: nowrap;
      padding-bottom: 4px;
      scrollbar-width: none;
    }
    .categorias-scroll::-webkit-scrollbar { display: none; }

    /* --- SISTEMA DE NOTIFICAÇÕES TOAST --- */
    #toast-container {
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 9999;
      display: flex;
      flex-direction: column;
      gap: 12px;
      max-width: 360px;
      width: calc(100% - 40px);
      pointer-events: none;
    }
    .toast {
      pointer-events: auto;
      display: flex;
      align-items: flex-start;
      gap: 12px;
      padding: 14px 16px;
      border-radius: 12px;
      background: #111827;
      border: 1px solid rgba(255, 255, 255, 0.1);
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.8);
      position: relative;
      overflow: hidden;
      transform: translateX(120%);
      transition: transform 0.35s cubic-bezier(0.21, 1.02, 0.73, 1), opacity 0.35s ease;
      opacity: 0;
    }
    .toast.show { transform: translateX(0); opacity: 1; }
    .toast-icon { font-size: 1.25rem; flex-shrink: 0; margin-top: 2px; }
    .toast-content { flex: 1; }
    .toast-title { font-weight: 700; font-size: 0.875rem; color: #ffffff; margin-bottom: 2px; }
    .toast-message { font-size: 0.775rem; color: #9ca3af; line-height: 1.35; }
    .toast-close { background: none; border: none; color: #6b7280; cursor: pointer; padding: 2px; font-size: 0.875rem; transition: color 0.2s; }
    .toast-close:hover { color: #ffffff; }
    .toast-progress { position: absolute; bottom: 0; left: 0; height: 3px; width: 100%; transform-origin: left; }

    .toast-success { border-color: rgba(0, 255, 102, 0.4); }
    .toast-success .toast-icon { color: #00FF66; }
    .toast-success .toast-progress { background: #00FF66; }

    .toast-error { border-color: rgba(239, 68, 68, 0.4); }
    .toast-error .toast-icon { color: #ef4444; }
    .toast-error .toast-progress { background: #ef4444; }

    .toast-info { border-color: rgba(59, 130, 246, 0.4); }
    .toast-info .toast-icon { color: #3b82f6; }
    .toast-info .toast-progress { background: #3b82f6; }
  </style>
</head>
<body class="min-h-screen flex flex-col justify-between pb-32">

  <!-- CONTAINER DE TOASTS -->
  <div id="toast-container"></div>

  <header class="sticky top-0 z-40 bg-gray-900/95 backdrop-blur-md border-b border-gray-800 px-3 py-2">
    <div class="max-w-6xl mx-auto flex justify-between items-center">
      <a href="../index.php" class="flex items-center gap-1.5">
        <i class="fa-solid fa-futbol text-lg text-neon"></i>
        <span class="text-sm font-extrabold tracking-wider text-white">ARENA<span class="text-neon">BET</span></span>
      </a>
      <div class="flex items-center gap-2">
        <div class="bg-gray-950 border border-emerald-500/40 rounded-lg px-2.5 py-1 flex items-center gap-1.5">
          <i class="fa-solid fa-wallet text-neon text-[10px]"></i>
          <div>
            <div class="text-[8px] text-gray-400 uppercase leading-none">Saldo</div>
            <div class="text-[10px] font-bold text-white">R$ <?= number_format($saldo, 2, ',', '.') ?></div>
          </div>
          <button onclick="atualizarSaldo()" class="ml-1 text-gray-400 hover:text-neon transition text-xs p-1" title="Atualizar Saldo">
            <i id="iconRefresh" class="fa-solid fa-rotate"></i>
          </button>
        </div>
        <a href="../login.php" class="text-gray-400 hover:text-white text-xs"><i class="fa-solid fa-right-from-bracket text-sm"></i></a>
      </div>
    </div>
  </header>

  <main class="max-w-6xl mx-auto px-3 pt-4 w-full flex-1 space-y-4">
    <div class="bg-gradient-to-r from-emerald-950 via-gray-900 to-gray-950 border border-emerald-500/30 rounded-xl p-3 sm:p-4 flex justify-between items-center">
      <div>
        <h2 class="text-xs sm:text-base font-extrabold text-white">Olá, <span class="text-neon"><?= htmlspecialchars($usuario_nome) ?></span>!</h2>
        <p class="text-[10px] sm:text-xs text-gray-300">Escolha seus palpites ou consulte suas apostas abaixo.</p>
      </div>
      <button onclick="abrirModalPix()" class="px-3 py-1.5 bg-neon font-bold text-[10px] sm:text-xs rounded-lg hover:bg-emerald-400 transition shadow-lg flex items-center gap-1.5">
        <i class="fa-solid fa-qrcode"></i> Depositar PIX
      </button>
    </div>

    <!-- SELETOR DE ABAS -->
    <div class="flex border-b border-gray-800 gap-3 text-xs font-bold">
      <button onclick="alternarAba('apostar')" id="tabApostar" class="pb-2 border-b-2 border-emerald-500 text-neon flex items-center gap-1.5">
        <i class="fa-solid fa-futbol"></i> Jogos & Meus Bilhetes
      </button>
      <button onclick="alternarAba('historico')" id="tabHistorico" class="pb-2 border-b-2 border-transparent text-gray-400 hover:text-white flex items-center gap-1.5">
        <i class="fa-solid fa-clock-rotate-left"></i> Histórico Completo
      </button>
    </div>

    <!-- CONTEÚDO APOSTAR -->
    <div id="conteudoApostar" class="space-y-4">
      
      <!-- ACORDEON DE MEUS BILHETES DE APOSTAS -->
      <div class="bg-gray-900 border border-gray-800 rounded-xl p-4 space-y-3">
        <div class="flex items-center justify-between cursor-pointer" onclick="toggleAcordeonBilhetes()">
          <h3 class="text-xs font-bold text-gray-300 uppercase tracking-wider flex items-center gap-1.5">
            <i class="fa-solid fa-ticket text-neon"></i> Meus Bilhetes de Apostas (Recentes)
          </h3>
          <div class="flex items-center gap-2">
            <span class="text-[10px] text-gray-400 font-semibold">(<?= count($minhas_apostas) ?>)</span>
            <button type="button" class="text-gray-400 hover:text-white text-xs focus:outline-none p-1">
              <i id="iconeAcordeonBilhetes" class="fa-solid fa-chevron-down transition-transform duration-300"></i>
            </button>
          </div>
        </div>

        <div id="conteudoAcordeonBilhetes" class="space-y-2 pt-1 transition-all duration-300">
          <?php if (empty($minhas_apostas)): ?>
            <div class="text-center py-6 px-4 flex flex-col items-center justify-center bg-gray-950/60 rounded-xl border border-gray-800/60 my-2">
              <div class="w-10 h-10 rounded-full bg-emerald-500/10 flex items-center justify-center text-neon text-lg mb-2 border border-emerald-500/30">
                <i class="fa-solid fa-ticket"></i>
              </div>
              <h4 class="text-white font-bold text-xs mb-1">Nenhum bilhete ativo</h4>
              <p class="text-gray-400 text-[10px] max-w-xs">Faça sua primeira aposta selecionando uma partida abaixo para começar a lucrar.</p>
            </div>
          <?php else: ?>
            <div class="space-y-2">
              <?php foreach ($minhas_apostas as $ap): ?>
                <?php 
                  $corStatus = 'bg-yellow-500/20 text-yellow-400 border-yellow-500/40';
                  if ($ap['status'] === 'Ganha') { $corStatus = 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'; }
                  if ($ap['status'] === 'Perdida') { $corStatus = 'bg-red-500/20 text-red-400 border-red-500/40'; }
                ?>
                <div class="bg-gray-950 border border-gray-800 rounded-lg p-3 flex flex-col sm:flex-row justify-between items-center gap-2 relative">
                  <div>
                    <div class="text-[11px] font-bold text-white mb-0.5">
                      <?= htmlspecialchars($ap['time_mandante']) ?> <span class="text-neon">VS</span> <?= htmlspecialchars($ap['time_visitante']) ?>
                    </div>
                    <div class="text-[10px] text-gray-400">
                      Palpite: <span class="text-white font-bold"><?= $ap['tipo_aposta'] ?></span> | Odd: <span class="text-emerald-400 font-bold"><?= number_format($ap['odd'], 2) ?></span>
                    </div>
                    <div class="text-[9px] text-gray-500 mt-0.5">Data: <?= date('d/m/Y H:i', strtotime($ap['criado_em'])) ?></div>
                  </div>
                  <div class="flex items-center gap-3 text-right">
                    <div>
                      <div class="text-[8px] text-gray-400 uppercase">Apostado</div>
                      <div class="text-[10px] font-bold text-white">R$ <?= number_format($ap['valor'], 2, ',', '.') ?></div>
                    </div>
                    <div>
                      <div class="text-[8px] text-gray-400 uppercase">Retorno</div>
                      <div class="text-[11px] font-extrabold text-neon">R$ <?= number_format($ap['possivel_retorno'], 2, ',', '.') ?></div>
                    </div>
                    <div>
                      <span class="px-2 py-0.5 border text-[10px] font-bold rounded-md uppercase <?= $corStatus ?>">
                        <?= $ap['status'] ?>
                      </span>
                    </div>
                    <a href="index.php?ocultar_aposta=<?= $ap['id'] ?>" onclick="return confirm('Remover este bilhete da sua tela principal?')" class="w-6 h-6 bg-red-600/20 border border-red-500/40 text-red-400 hover:bg-red-600 hover:text-white rounded-md flex items-center justify-center text-[10px] transition" title="Remover da tela">
                      <i class="fa-solid fa-xmark"></i>
                    </a>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      </div>

      <!-- ACORDEON DE PARTIDAS DISPONÍVEIS -->
      <div class="bg-gray-900 border border-gray-800 rounded-xl p-4 space-y-3">
        <div class="flex items-center justify-between cursor-pointer" onclick="toggleAcordeonJogos()">
          <h3 class="text-xs font-bold text-gray-300 uppercase tracking-wider flex items-center gap-1.5">
            <i class="fa-solid fa-fire text-neon"></i> Partidas Disponíveis para Palpite
          </h3>
          <div class="flex items-center gap-2">
            <span class="text-[10px] text-gray-400 font-semibold">(<?= count($jogos) ?> jogos)</span>
            <button type="button" class="text-gray-400 hover:text-white text-xs focus:outline-none p-1">
              <i id="iconeAcordeonJogos" class="fa-solid fa-chevron-down transition-transform duration-300"></i>
            </button>
          </div>
        </div>

        <div id="conteudoAcordeonJogos" class="space-y-3 pt-2 transition-all duration-300">
          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div class="relative w-full">
              <span class="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-500">
                <i class="fa-solid fa-magnifying-glass text-xs"></i>
              </span>
              <input type="text" id="filtroJogos" onkeyup="filtrarJogos()" placeholder="Buscar time (ex: Cruzeiro)..." class="w-full bg-gray-950 border border-gray-800 rounded-lg pl-8 pr-3 py-1.5 text-white text-xs focus:border-emerald-500 focus:outline-none placeholder-gray-500">
            </div>
          </div>

          <!-- MENU DE CATEGORIAS / CAMPEONATOS (PÍLULAS COM SCROLL HORIZONTAL) -->
          <?php
          $categorias = ['Todos'];
          foreach ($jogos as $j) {
              $cat = !empty($j['categoria']) ? $j['categoria'] : 'Brasileirão';
              if (!in_array($cat, $categorias)) { $categorias[] = $cat; }
          }
          if (count($categorias) > 1):
          ?>
          <div class="categorias-scroll py-1">
            <?php foreach ($categorias as $index => $cat): ?>
              <button onclick="filtrarCategoria('<?= htmlspecialchars($cat) ?>', this)" class="cat-btn px-3 py-1.5 rounded-full text-xs font-bold border transition <?= $index === 0 ? 'bg-neon text-black border-neon' : 'bg-gray-950 text-gray-300 border-gray-800 hover:border-emerald-500/50' ?>">
                <?= htmlspecialchars($cat) ?>
              </button>
            <?php endforeach; ?>
          </div>
          <?php endif; ?>

          <?php if (empty($jogos)): ?>
            <div class="bg-gray-950 border border-gray-800 rounded-xl p-8 text-center flex flex-col items-center justify-center">
              <div class="w-10 h-10 rounded-full bg-emerald-500/10 flex items-center justify-center text-neon text-lg mb-2 border border-emerald-500/30">
                <i class="fa-solid fa-calendar-xmark"></i>
              </div>
              <h4 class="text-white font-bold text-xs mb-1">Nenhum jogo aberto</h4>
              <p class="text-gray-400 text-[10px] max-w-xs">Não há partidas disponíveis no momento para palpites. Volte em breve!</p>
            </div>
          <?php else: ?>
            <div id="listaPartidas" class="space-y-3">
              <?php foreach ($jogos as $j): ?>
                <?php 
                  $catJogo = !empty($j['categoria']) ? $j['categoria'] : 'Brasileirão'; 
                  $is_super = (!empty($j['super_odd']) && $j['super_odd'] == 1);
                  $dataHoraJogo = $j['data_hora']; // Formato Y-m-d H:i:s
                ?>
                <div class="cartao-jogo bg-gray-950 border border-gray-800 rounded-xl p-4 shadow-lg relative <?= $is_super ? 'super-odd-card bg-emerald-950/20' : '' ?>" 
                     data-times="<?= strtolower(htmlspecialchars($j['time_mandante'] . ' ' . $j['time_visitante'])) ?>" 
                     data-categoria="<?= htmlspecialchars($catJogo) ?>"
                     data-horario="<?= $dataHoraJogo ?>"
                     data-jogoid="<?= $j['id'] ?>">
                  
                  <!-- SELO VISUAL DE SUPER ODD -->
                  <?php if ($is_super): ?>
                    <span class="absolute -top-2.5 left-4 bg-neon text-black text-[9px] font-extrabold px-2.5 py-0.5 rounded-full uppercase tracking-wider shadow-[0_0_12px_rgba(0,255,102,0.8)] flex items-center gap-1 z-10">
                      <i class="fa-solid fa-bolt"></i> SUPER ODD
                    </span>
                  <?php endif; ?>

                  <div class="flex justify-between items-center border-b border-gray-800 pb-2 mb-2 text-[10px] text-gray-400">
                    <span class="text-emerald-400 font-semibold flex items-center gap-1.5">
                      <i class="fa-solid fa-trophy text-[9px]"></i> <?= htmlspecialchars($catJogo) ?>
                      <!-- INDICADOR AO VIVO (INICIALMENTE OCULTO ATÉ O JAVASCRIPT VALIDAR O HORÁRIO) -->
                      <span class="live-indicator hidden items-center gap-1 bg-red-500/20 border border-red-500/40 text-red-400 px-2 py-0.5 rounded-full font-extrabold text-[8px] uppercase ml-2">
                        <span class="w-1.5 h-1.5 rounded-full bg-red-500 live-dot"></span> AO VIVO
                      </span>
                    </span>
                    <span><?= date('d/m/Y H:i', strtotime($dataHoraJogo)) ?></span>
                  </div>
                  
                  <div class="flex items-center justify-between mb-3">
                    <div class="flex items-center gap-2 w-5/12">
                      <?php if (!empty($j['logo_mandante'])): ?><img src="../<?= htmlspecialchars($j['logo_mandante']) ?>" class="w-7 h-7 rounded-full object-cover border border-gray-700"><?php endif; ?>
                      <span class="font-bold text-xs text-white"><?= htmlspecialchars($j['time_mandante']) ?></span>
                    </div>
                    <span class="text-[10px] font-bold text-gray-500">VS</span>
                    <div class="flex items-center justify-end gap-2 w-5/12">
                      <span class="font-bold text-xs text-white text-right"><?= htmlspecialchars($j['time_visitante']) ?></span>
                      <?php if (!empty($j['logo_visitante'])): ?><img src="../<?= htmlspecialchars($j['logo_visitante']) ?>" class="w-7 h-7 rounded-full object-cover border border-gray-700"><?php endif; ?>
                    </div>
                  </div>

                  <!-- CONTAINER DOS BOTÕES DE ODD (SERÁ BLOQUEADO SE O JOGO JÁ COMEÇOU) -->
                  <div class="odds-container space-y-2">
                    <!-- ODDS 1X2 TRADICIONAIS -->
                    <div class="grid grid-cols-3 gap-1.5 mb-3">
                      <button onclick="selecionarOdd(<?= $j['id'] ?>, 'Casa (1)', <?= $j['odd_1'] ?>, '<?= htmlspecialchars($j['time_mandante']) ?> x <?= htmlspecialchars($j['time_visitante']) ?>', '<?= $dataHoraJogo ?>')" class="btn-odd bg-gray-900 border border-emerald-500/30 hover:border-emerald-500 rounded-lg p-2 text-center transition group">
                        <div class="text-[9px] text-gray-400 group-hover:text-neon">Casa (1)</div>
                        <div class="font-extrabold text-xs text-white"><?= number_format($j['odd_1'], 2) ?></div>
                      </button>
                      <button onclick="selecionarOdd(<?= $j['id'] ?>, 'Empate (X)', <?= $j['odd_x'] ?>, '<?= htmlspecialchars($j['time_mandante']) ?> x <?= htmlspecialchars($j['time_visitante']) ?>', '<?= $dataHoraJogo ?>')" class="btn-odd bg-gray-900 border border-emerald-500/30 hover:border-emerald-500 rounded-lg p-2 text-center transition group">
                        <div class="text-[9px] text-gray-400 group-hover:text-neon">Empate (X)</div>
                        <div class="font-extrabold text-xs text-white"><?= number_format($j['odd_x'], 2) ?></div>
                      </button>
                      <button onclick="selecionarOdd(<?= $j['id'] ?>, 'Fora (2)', <?= $j['odd_2'] ?>, '<?= htmlspecialchars($j['time_mandante']) ?> x <?= htmlspecialchars($j['time_visitante']) ?>', '<?= $dataHoraJogo ?>')" class="btn-odd bg-gray-900 border border-emerald-500/30 hover:border-emerald-500 rounded-lg p-2 text-center transition group">
                        <div class="text-[9px] text-gray-400 group-hover:text-neon">Fora (2)</div>
                        <div class="font-extrabold text-xs text-white"><?= number_format($j['odd_2'], 2) ?></div>
                      </button>
                    </div>

                    <!-- MERCADOS EXTRAS (EX: QUEM VAI FAZER O GOL / CAIO JORGE) -->
                    <?php
                    if (isset($pdo)) {
                        try {
                            $stmtExtra = $pdo->prepare("SELECT * FROM mercados_extras WHERE jogo_id = ? AND status = 'aberto'");
                            $stmtExtra->execute([$j['id']]);
                            $extras = $stmtExtra->fetchAll();
                            if (!empty($extras)) {
                                echo '<div class="border-t border-gray-800 pt-2.5 mt-2 space-y-2">';
                                foreach ($extras as $ex) {
                                    echo '<div class="text-[10px] text-gray-300 font-bold mb-1 flex items-center gap-1"><i class="fa-solid fa-star text-neon"></i> ' . htmlspecialchars($ex['pergunta']) . '</div>';
                                    echo '<div class="grid grid-cols-2 gap-1.5">';
                                    echo '<button onclick="selecionarOdd('.$j['id'].', \''.htmlspecialchars($ex['opcao'], ENT_QUOTES).'\', '.$ex['odd'].', \''.htmlspecialchars($j['time_mandante']).' x '.htmlspecialchars($j['time_visitante']).'\', \''.$dataHoraJogo.'\')" class="btn-odd bg-gray-900 border border-neon/40 hover:border-neon rounded-lg p-2 text-center transition group flex justify-between items-center px-3">';
                                    echo '<span class="text-[10px] text-white font-semibold">'.htmlspecialchars($ex['opcao']).'</span>';
                                    echo '<span class="font-extrabold text-xs text-neon">'.number_format($ex['odd'], 2).'</span>';
                                    echo '</button>';
                                    echo '</div>';
                                }
                                echo '</div>';
                            }
                        } catch (Exception $e) {}
                    }
                    ?>
                  </div>

                  <!-- AVISO VISUAL GRANDE DE JOGO EM ANDAMENTO / TRANCADO -->
                  <div class="aviso-trancado hidden mt-2 bg-red-500/15 border border-red-500/50 rounded-xl p-3 text-center">
                    <div class="text-red-400 font-extrabold text-xs flex items-center justify-center gap-1.5 uppercase">
                      <i class="fa-solid fa-lock"></i> Jogo em Andamento - Apostas Encerradas
                    </div>
                    <p class="text-[10px] text-gray-400 mt-1">Esta partida já começou. As apostas foram trancadas automaticamente.</p>
                  </div>

                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- CONTEÚDO HISTÓRICO -->
    <div id="conteudoHistorico" class="hidden space-y-3">
      <div class="bg-gray-900 border border-gray-800 rounded-xl p-4">
        <h3 class="text-xs font-bold text-gray-300 uppercase tracking-wider mb-3 flex items-center gap-1.5">
          <i class="fa-solid fa-clock-rotate-left text-neon"></i> Histórico Geral de Todas as Apostas
        </h3>
        <?php if (empty($historico_completo)): ?>
          <p class="text-[10px] text-gray-500 text-center py-3">Nenhum registro no histórico.</p>
        <?php else: ?>
          <div class="space-y-2">
            <?php foreach ($historico_completo as $ap): ?>
              <?php 
                $corStatus = 'bg-yellow-500/20 text-yellow-400 border-yellow-500/40';
                if ($ap['status'] === 'Ganha') { $corStatus = 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40'; }
                if ($ap['status'] === 'Perdida') { $corStatus = 'bg-red-500/20 text-red-400 border-red-500/40'; }
              ?>
              <div class="bg-gray-950 border border-gray-800 rounded-lg p-3 flex flex-col sm:flex-row justify-between items-center gap-2">
                <div>
                  <div class="text-[11px] font-bold text-white mb-0.5">
                    <?= htmlspecialchars($ap['time_mandante']) ?> <span class="text-neon">VS</span> <?= htmlspecialchars($ap['time_visitante']) ?>
                  </div>
                  <div class="text-[10px] text-gray-400">
                    Palpite: <span class="text-white font-bold"><?= $ap['tipo_aposta'] ?></span> | Odd: <span class="text-emerald-400 font-bold"><?= number_format($ap['odd'], 2) ?></span>
                  </div>
                  <div class="text-[9px] text-gray-500 mt-0.5">Realizada em: <?= date('d/m/Y H:i', strtotime($ap['criado_em'])) ?></div>
                </div>
                <div class="flex items-center gap-3 text-right">
                  <div>
                    <div class="text-[8px] text-gray-400 uppercase">Apostado</div>
                    <div class="text-[10px] font-bold text-white">R$ <?= number_format($ap['valor'], 2, ',', '.') ?></div>
                  </div>
                  <div>
                    <div class="text-[8px] text-gray-400 uppercase">Retorno</div>
                    <div class="text-[11px] font-extrabold text-neon">R$ <?= number_format($ap['possivel_retorno'], 2, ',', '.') ?></div>
                  </div>
                  <div>
                    <span class="px-2 py-0.5 border text-[10px] font-bold rounded-md uppercase <?= $corStatus ?>">
                      <?= $ap['status'] ?>
                    </span>
                  </div>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </main>

  <!-- PAINEL FLUTUANTE DE APOSTA -->
  <div id="painelAposta" class="fixed bottom-0 left-0 right-0 bg-gray-900 border-t border-emerald-500/50 p-3 shadow-2xl z-50 hidden">
    <div class="max-w-3xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-3">
      <div>
        <div class="text-[10px] text-neon font-bold uppercase tracking-wider"><i class="fa-solid fa-ticket"></i> Bilhete Selecionado</div>
        <div id="infoPartida" class="text-xs font-extrabold text-white"></div>
        <div class="text-[10px] text-gray-400">Palpite: <span id="infoTipo" class="text-white font-bold"></span> | Odd: <span id="infoOdd" class="text-emerald-400 font-bold"></span></div>
      </div>
      <form method="POST" onsubmit="return processarAposta(this)" class="flex items-center gap-2">
        <input type="hidden" name="fazer_aposta" value="1">
        <input type="hidden" name="jogo_id" id="inputJogoId">
        <input type="hidden" name="tipo_aposta" id="inputTipoAposta">
        <input type="hidden" name="odd" id="inputOdd">
        <input type="hidden" id="inputHorarioJogo">
        <div>
          <label class="block text-[8px] text-gray-400 uppercase">Valor (R$)</label>
          <input type="number" step="0.01" name="valor_aposta" id="inputValorAposta" required min="1" max="<?= $saldo ?>" value="10.00" oninput="calcularRetorno()" class="w-20 bg-gray-950 border border-gray-800 rounded-md p-1.5 text-white font-bold text-xs">
        </div>
        <div class="text-right">
          <div class="text-[8px] text-gray-400 uppercase">Retorno</div>
          <div class="text-xs font-extrabold text-neon" id="retornoPossivel">R$ 0,00</div>
        </div>
        <button type="submit" id="btnApostar" class="bg-neon font-extrabold px-4 py-2.5 rounded-lg text-black hover:bg-emerald-400 transition text-[10px]">APOSTAR</button>
      </form>
    </div>
  </div>

  <!-- MODAL PIX -->
  <div id="modalPix" class="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 hidden items-center justify-center p-3">
    <div class="bg-gray-900 border border-emerald-500/40 rounded-xl w-full max-w-sm p-5 relative shadow-2xl">
      <button onclick="fecharModalPix()" class="absolute top-3 right-3 text-gray-400 hover:text-white"><i class="fa-solid fa-xmark text-lg"></i></button>
      <div class="text-center mb-3">
        <i class="fa-solid fa-qrcode text-2xl text-neon mb-1.5"></i>
        <h3 class="text-sm font-bold text-white">Depósito via PIX</h3>
      </div>
      <div class="bg-gray-950 p-3 rounded-lg border border-gray-800 mb-3 space-y-1.5 text-[10px]">
        <div class="flex justify-between"><span class="text-gray-400">Favorecido:</span><span class="font-bold text-white">Camila Baltazar da Silva</span></div>
        <div class="flex justify-between items-center pt-1.5 border-t border-gray-800">
          <span class="text-gray-400">Chave PIX:</span>
          <div class="flex items-center gap-1.5">
            <span id="chavePixText" class="font-mono text-neon font-bold">48999868365</span>
            <button onclick="copiarChavePix()" class="bg-emerald-500/20 text-neon px-2 py-0.5 rounded text-[9px]">Copiar</button>
          </div>
        </div>
      </div>
      <form method="POST" onsubmit="return processarPix(this)" class="space-y-3">
        <input type="hidden" name="enviar_pix" value="1">
        <div>
          <label class="block text-[10px] font-medium text-gray-300 mb-1">Valor (R$)</label>
          <input type="number" step="0.01" id="inputValorPix" name="valor_deposito" required min="5" value="50.00" class="w-full bg-gray-950 border border-gray-800 rounded-lg p-2.5 text-white font-bold text-xs">
        </div>
        <button type="submit" id="btnPix" class="w-full bg-neon font-bold py-2.5 rounded-lg text-black hover:bg-emerald-400 text-xs">JÁ PAGUEI / AVISAR ADMIN</button>
      </form>
    </div>
  </div>

  <!-- SCRIPT DE TOASTS, ACORDEONS, TRAVA DE HORÁRIO E BOLINHA AO VIVO -->
  <script>
    const saldoAtual = <?= floatval($saldo) ?>;
    let categoriaAtual = 'Todos';

    const Toast = {
      show(title, message, type = 'info', duration = 4000) {
        const container = document.getElementById('toast-container');
        if (!container) return;

        const icons = {
          success: 'fa-circle-check',
          error: 'fa-circle-xmark',
          warning: 'fa-triangle-exclamation',
          info: 'fa-circle-info'
        };

        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        
        toast.innerHTML = `
          <i class="fa-solid ${icons[type] || icons.info} toast-icon"></i>
          <div class="toast-content">
            <div class="toast-title">${title}</div>
            ${message ? `<div class="toast-message">${message}</div>` : ''}
          </div>
          <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>
          <div class="toast-progress"></div>
        `;

        container.appendChild(toast);
        setTimeout(() => toast.classList.add('show'), 10);

        const progress = toast.querySelector('.toast-progress');
        progress.style.transition = `transform ${duration}ms linear`;
        setTimeout(() => progress.style.transform = 'scaleX(0)', 20);

        setTimeout(() => {
          toast.classList.remove('show');
          setTimeout(() => toast.remove(), 350);
        }, duration);
      },

      success(title, message, duration) { this.show(title, message, 'success', duration); },
      error(title, message, duration) { this.show(title, message, 'error', duration); },
      warning(title, message, duration) { this.show(title, message, 'warning', duration); },
      info(title, message, duration) { this.show(title, message, 'info', duration); }
    };

    <?php if (!empty($toast_sucesso)): ?>
      window.addEventListener('DOMContentLoaded', () => {
        Toast.success('Sucesso!', '<?= addslashes($toast_sucesso) ?>');
      });
    <?php endif; ?>

    <?php if (!empty($toast_erro)): ?>
      window.addEventListener('DOMContentLoaded', () => {
        Toast.error('Atenção', '<?= addslashes($toast_erro) ?>');
      });
    <?php endif; ?>

    // Validação contínua do horário do jogo (Trava + Bolinha Ao Vivo)
    function verificarAndamentoJogos() {
      const agora = new Date();
      const cartoes = document.querySelectorAll('.cartao-jogo');

      cartoes.forEach(cartao => {
        const horarioStr = cartao.getAttribute('data-horario'); // 'YYYY-MM-DD HH:MM:SS'
        if (!horarioStr) return;

        // Converte string SQL para objeto Date considerando o horário local
        const dataJogo = new Date(horarioStr.replace(/-/g, '/'));
        const oddsContainer = cartao.querySelector('.odds-container');
        const avisoTrancado = cartao.querySelector('.aviso-trancado');
        const liveIndicator = cartao.querySelector('.live-indicator');

        if (agora >= dataJogo) {
          // Jogo já começou ou passou do horário: tranca e mostra ao vivo
          if (oddsContainer) oddsContainer.style.display = 'none';
          if (avisoTrancado) avisoTrancado.classList.remove('hidden');
          if (liveIndicator) {
            liveIndicator.classList.remove('hidden');
            liveIndicator.classList.add('flex');
          }
          cartao.style.backgroundColor = 'rgba(6, 78, 59, 0.15)'; // Fundo verde clarinho diferenciado
        } else {
          // Jogo ainda não começou
          if (oddsContainer) oddsContainer.style.display = 'block';
          if (avisoTrancado) avisoTrancado.classList.add('hidden');
          if (liveIndicator) {
            liveIndicator.classList.add('hidden');
            liveIndicator.classList.remove('flex');
          }
        }
      });
    }

    // Restaura estado dos acordeons e inicia verificador ao carregar
    document.addEventListener("DOMContentLoaded", function() {
      verificarAndamentoJogos();
      // Executa a verificação a cada 10 segundos para trancar em tempo real caso o usuário deixe a tela aberta
      setInterval(verificarAndamentoJogos, 10000);

      const acordeonBilhetes = localStorage.getItem('acordeon_bilhetes_cliente');
      if (acordeonBilhetes === 'false') {
        const conteudo = document.getElementById('conteudoAcordeonBilhetes');
        const icone = document.getElementById('iconeAcordeonBilhetes');
        if (conteudo && icone) {
          conteudo.style.display = 'none';
          icone.style.transform = 'rotate(-90deg)';
        }
      }

      const acordeonJogos = localStorage.getItem('acordeon_jogos_cliente');
      if (acordeonJogos === 'false') {
        const conteudo = document.getElementById('conteudoAcordeonJogos');
        const icone = document.getElementById('iconeAcordeonJogos');
        if (conteudo && icone) {
          conteudo.style.display = 'none';
          icone.style.transform = 'rotate(-90deg)';
        }
      }
    });

    function toggleAcordeonBilhetes() {
      const conteudo = document.getElementById('conteudoAcordeonBilhetes');
      const icone = document.getElementById('iconeAcordeonBilhetes');
      if (conteudo.style.display === 'none') {
        conteudo.style.display = 'block';
        icone.style.transform = 'rotate(0deg)';
        localStorage.setItem('acordeon_bilhetes_cliente', 'true');
      } else {
        conteudo.style.display = 'none';
        icone.style.transform = 'rotate(-90deg)';
        localStorage.setItem('acordeon_bilhetes_cliente', 'false');
      }
    }

    function toggleAcordeonJogos() {
      const conteudo = document.getElementById('conteudoAcordeonJogos');
      const icone = document.getElementById('iconeAcordeonJogos');
      if (conteudo.style.display === 'none') {
        conteudo.style.display = 'block';
        icone.style.transform = 'rotate(0deg)';
        localStorage.setItem('acordeon_jogos_cliente', 'true');
      } else {
        conteudo.style.display = 'none';
        icone.style.transform = 'rotate(-90deg)';
        localStorage.setItem('acordeon_jogos_cliente', 'false');
      }
    }

    function atualizarSaldo() {
      const icon = document.getElementById('iconRefresh');
      if (icon) icon.classList.add('fa-spin');
      Toast.info('Atualizando...', 'Verificando saldo e bilhetes atualizados.');
      setTimeout(() => { window.location.reload(); }, 500);
    }

    function copiarChavePix() {
      const chave = document.getElementById('chavePixText').innerText;
      navigator.clipboard.writeText(chave).then(() => {
        Toast.success('Copiado!', 'Chave PIX copiada para a área de transferência.');
      }).catch(() => {
        Toast.error('Erro', 'Não foi possível copiar a chave PIX.');
      });
    }

    // FILTRO COMBINADO DE BUSCA POR TIME E CATEGORIA
    function filtrarJogos() {
      const termo = document.getElementById('filtroJogos').value.toLowerCase().trim();
      const cartoes = document.querySelectorAll('.cartao-jogo');

      cartoes.forEach(cartao => {
        const times = cartao.getAttribute('data-times');
        const categoria = cartao.getAttribute('data-categoria');
        
        const matchTermo = times.includes(termo);
        const matchCat = (categoriaAtual === 'Todos' || categoria === categoriaAtual);

        if (matchTermo && matchCat) {
          cartao.style.display = 'block';
        } else {
          cartao.style.display = 'none';
        }
      });
    }

    function filtrarCategoria(cat, btn) {
      categoriaAtual = cat;
      
      document.querySelectorAll('.cat-btn').forEach(b => {
        b.className = 'cat-btn px-3 py-1.5 rounded-full text-xs font-bold border transition bg-gray-950 text-gray-300 border-gray-800 hover:border-emerald-500/50';
      });
      btn.className = 'cat-btn px-3 py-1.5 rounded-full text-xs font-bold border transition bg-neon text-black border-neon';

      filtrarJogos();
    }

    function alternarAba(aba) {
      if (aba === 'apostar') {
        document.getElementById('conteudoApostar').classList.remove('hidden');
        document.getElementById('conteudoHistorico').classList.add('hidden');
        document.getElementById('tabApostar').className = 'pb-2 border-b-2 border-emerald-500 text-neon flex items-center gap-1.5';
        document.getElementById('tabHistorico').className = 'pb-2 border-b-2 border-transparent text-gray-400 hover:text-white flex items-center gap-1.5';
      } else {
        document.getElementById('conteudoApostar').classList.add('hidden');
        document.getElementById('conteudoHistorico').classList.remove('hidden');
        document.getElementById('tabApostar').className = 'pb-2 border-b-2 border-transparent text-gray-400 hover:text-white flex items-center gap-1.5';
        document.getElementById('tabHistorico').className = 'pb-2 border-b-2 border-emerald-500 text-neon flex items-center gap-1.5';
      }
    }

    let oddAtual = 0;
    function selecionarOdd(jogoId, tipo, odd, partida, horarioJogo) {
      // Dupla checagem antes de abrir o painel de aposta
      const agora = new Date();
      const dataJogo = new Date(horarioJogo.replace(/-/g, '/'));
      if (agora >= dataJogo) {
        Toast.error('Apostas Encerradas', 'Este jogo já começou! Não é permitido apostar.');
        document.getElementById('painelAposta').classList.add('hidden');
        verificarAndamentoJogos();
        return;
      }

      document.getElementById('painelAposta').classList.remove('hidden');
      document.getElementById('inputJogoId').value = jogoId;
      document.getElementById('inputTipoAposta').value = tipo;
      document.getElementById('inputOdd').value = odd;
      document.getElementById('inputHorarioJogo').value = horarioJogo;
      document.getElementById('infoPartida').innerText = partida;
      document.getElementById('infoTipo').innerText = tipo;
      document.getElementById('infoOdd').innerText = odd.toFixed(2);
      oddAtual = odd;
      calcularRetorno();
    }

    function calcularRetorno() {
      const inputValor = document.getElementById('inputValorAposta');
      const valor = parseFloat(inputValor.value) || 0;
      const btnApostar = document.getElementById('btnApostar');

      if (valor > saldoAtual) {
        inputValor.style.borderColor = '#ef4444';
        btnApostar.style.opacity = '0.5';
      } else {
        inputValor.style.borderColor = '#1f2937';
        btnApostar.style.opacity = '1';
      }

      document.getElementById('retornoPossivel').innerText = 'R$ ' + (valor * oddAtual).toFixed(2).replace('.', ',');
    }

    function processarAposta(form) {
      const horarioJogo = document.getElementById('inputHorarioJogo').value;
      const agora = new Date();
      const dataJogo = new Date(horarioJogo.replace(/-/g, '/'));

      if (agora >= dataJogo) {
        Toast.error('Apostas Encerradas', 'O horário deste jogo já começou! Aposta recusada.');
        document.getElementById('painelAposta').classList.add('hidden');
        verificarAndamentoJogos();
        return false;
      }

      const valor = parseFloat(document.getElementById('inputValorAposta').value) || 0;
      if (valor <= 0) {
        Toast.error('Valor Inválido', 'Digite um valor maior que zero para apostar.');
        return false;
      }
      if (valor > saldoAtual) {
        Toast.error('Saldo Insuficiente', 'Você não tem saldo suficiente para esta aposta. Faça um depósito via PIX!');
        return false;
      }

      const btn = document.getElementById('btnApostar');
      btn.disabled = true;
      btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processando...';
      return true;
    }

    function processarPix(form) {
      const valor = parseFloat(document.getElementById('inputValorPix').value) || 0;
      if (valor < 5) {
        Toast.error('Valor Mínimo', 'O valor mínimo para depósito via PIX é R$ 5,00.');
        return false;
      }

      const btn = form.querySelector('button[type="submit"]');
      btn.disabled = true;
      btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Notificando Admin...';
      return true;
    }

    function abrirModalPix() { document.getElementById('modalPix').classList.remove('hidden'); document.getElementById('modalPix').classList.add('flex'); }
    function fecharModalPix() { document.getElementById('modalPix').classList.add('hidden'); document.getElementById('modalPix').classList.remove('flex'); }
  </script>
</body>
</html>