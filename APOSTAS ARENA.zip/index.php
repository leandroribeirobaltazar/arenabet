<?php
// Tenta carregar a conexão, mas evita crash se o banco estiver sem tabelas
@include_once 'conexao.php';

$ultimos_resultados = [];
if (isset($pdo)) {
    try {
        $stmt = $pdo->query("SELECT * FROM jogos WHERE status = 'encerrado' ORDER BY data_hora DESC LIMIT 5");
        $ultimos_resultados = $stmt->fetchAll();
    } catch (Exception $e) {
        // Ignora caso a tabela ainda não exista
    }
}

$proximos_jogos = [];
if (isset($pdo)) {
    try {
        $stmt = $pdo->query("SELECT * FROM jogos WHERE status = 'aberto' ORDER BY data_hora ASC");
        $proximos_jogos = $stmt->fetchAll();
    } catch (Exception $e) {
        // Ignora caso a tabela ainda não exista
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Arena Bet - Apostas Esportivas</title>
  <meta name="keywords" content="Arena Bet, faça aqui sua odd, dobre o seu valor, as melhores odds do mercado, pagamento instantâneo via Pix, Aproveite, arena apostas esportivas, aposta online, palpites de futebol, bilhete de aposta, odds, lucros">
  <meta name="description" content="A melhor arena de apostas esportivas e palpites de futebol do Brasil. Crie sua conta, faça sua odd e lucre na ArenaBet!">

  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  
  <style>
    :root {
      --neon-green: #00FF66;
      --neon-green-glow: rgba(0, 255, 102, 0.35);
      --bg-dark: #07090e;
      --card-bg: #111827;
    }
    body {
      background-color: var(--bg-dark);
      color: #ffffff;
      font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
    }
    .border-neon {
      border-color: var(--neon-green);
    }
    .text-neon {
      color: var(--neon-green);
      text-shadow: 0 0 10px var(--neon-green-glow);
    }
    .bg-neon {
      background-color: var(--neon-green);
      color: #000000;
    }
    .shadow-neon {
      box-shadow: 0 0 20px var(--neon-green-glow);
    }
    .slide-item {
      display: none;
      opacity: 0;
      transition: opacity 0.8s ease-in-out;
    }
    .slide-item.active {
      display: block;
      opacity: 1;
    }

    /* --- SISTEMA DE NOTIFICAÇÕES TOAST (ESTILOS CUSTOMIZADOS) --- */
    #toast-container {
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 9999;
      display: flex;
      flex-direction: column;
      gap: 12px;
      max-width: 360px;
      width: calc(100% - 40px);
      pointer-events: none;
    }
    .toast {
      pointer-events: auto;
      display: flex;
      align-items: flex-start;
      gap: 12px;
      padding: 14px 16px;
      border-radius: 12px;
      background: #111827;
      border: 1px solid rgba(255, 255, 255, 0.1);
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.8);
      position: relative;
      overflow: hidden;
      transform: translateX(120%);
      transition: transform 0.35s cubic-bezier(0.21, 1.02, 0.73, 1), opacity 0.35s ease;
      opacity: 0;
    }
    .toast.show {
      transform: translateX(0);
      opacity: 1;
    }
    .toast-icon {
      font-size: 1.25rem;
      flex-shrink: 0;
      margin-top: 2px;
    }
    .toast-content {
      flex: 1;
    }
    .toast-title {
      font-weight: 700;
      font-size: 0.875rem;
      color: #ffffff;
      margin-bottom: 2px;
    }
    .toast-message {
      font-size: 0.775rem;
      color: #9ca3af;
      line-height: 1.35;
    }
    .toast-close {
      background: none;
      border: none;
      color: #6b7280;
      cursor: pointer;
      padding: 2px;
      font-size: 0.875rem;
      transition: color 0.2s;
    }
    .toast-close:hover {
      color: #ffffff;
    }
    .toast-progress {
      position: absolute;
      bottom: 0;
      left: 0;
      height: 3px;
      width: 100%;
      transform-origin: left;
    }

    /* Cores e Temas das Notificações */
    .toast-success { border-color: rgba(0, 255, 102, 0.4); }
    .toast-success .toast-icon { color: #00FF66; }
    .toast-success .toast-progress { background: #00FF66; }

    .toast-error { border-color: rgba(239, 68, 68, 0.4); }
    .toast-error .toast-icon { color: #ef4444; }
    .toast-error .toast-progress { background: #ef4444; }

    .toast-warning { border-color: rgba(245, 158, 11, 0.4); }
    .toast-warning .toast-icon { color: #f59e0b; }
    .toast-warning .toast-progress { background: #f59e0b; }

    .toast-info { border-color: rgba(59, 130, 246, 0.4); }
    .toast-info .toast-icon { color: #3b82f6; }
    .toast-info .toast-progress { background: #3b82f6; }

    /* --- SKELETON LOADER (EFEITO SHIMMER) --- */
    @keyframes shimmer {
      0% { background-position: -200% 0; }
      100% { background-position: 200% 0; }
    }
    .skeleton {
      background: linear-gradient(90deg, #111827 0%, #1f2937 50%, #111827 100%);
      background-size: 200% 100%;
      animation: shimmer 1.5s infinite;
      border-radius: 0.75rem;
    }
  </style>
</head>
<body class="min-h-screen flex flex-col justify-between selection:bg-emerald-500 selection:text-black">

  <!-- CONTAINER DE TOASTS -->
  <div id="toast-container"></div>

  <!-- TOP BAR / HEADER (Limpo e sem poluição) -->
  <header class="sticky top-0 z-40 bg-gray-900/90 backdrop-blur-md border-b border-gray-800 px-4 py-3">
    <div class="max-w-6xl mx-auto flex justify-between items-center">
      <div class="flex items-center gap-2">
        <i class="fa-solid fa-futbol text-2xl text-neon"></i>
        <span class="text-xl font-extrabold tracking-wider text-white">ARENA<span class="text-neon">BET</span></span>
      </div>
      <div class="flex items-center gap-2 sm:gap-3">
        <button onclick="openModal('loginModal')" class="px-3 sm:px-4 py-1.5 text-xs sm:text-sm font-semibold text-gray-200 border border-emerald-500/50 hover:border-emerald-400 rounded-lg transition">
          Entrar
        </button>
        <button onclick="openModal('registerModal')" class="px-3 sm:px-4 py-1.5 text-xs sm:text-sm font-bold bg-neon hover:bg-emerald-400 rounded-lg shadow-neon transition">
          Cadastrar
        </button>
      </div>
    </div>
  </header>

  <!-- CARROSSEL DE BANNERS AUTOMÁTICO (2 SEGUNDOS) -->
  <section class="relative w-full max-w-6xl mx-auto px-4 pt-6">
    <div class="relative overflow-hidden rounded-2xl border border-gray-800 shadow-2xl h-48 sm:h-72 md:h-96 bg-gray-900">
      
      <!-- Banner 1 -->
      <div class="slide-item active absolute inset-0">
        <img src="https://images.pexels.com/photos/46798/the-ball-stadion-football-the-pitch-46798.jpeg?auto=compress&cs=tinysrgb&w=1200" class="w-full h-full object-cover" alt="Futebol 1">
        <div class="absolute inset-0 bg-gradient-to-t from-gray-950 via-gray-950/40 to-transparent flex flex-col justify-end p-6">
          <span class="bg-emerald-500/20 text-neon text-xs font-bold px-3 py-1 rounded-full w-fit mb-2 border border-emerald-500/40">BÔNUS DE BOAS-VINDAS</span>
          <h2 class="text-2xl sm:text-4xl font-extrabold text-white">DOBRE SEU PRIMEIRO DEPÓSITO</h2>
          <p class="text-gray-300 text-sm sm:text-base">Ganhe até R$ 500,00 extras para apostar nos jogos da semana.</p>
        </div>
      </div>

      <!-- Banner 2 -->
      <div class="slide-item absolute inset-0">
        <img src="https://images.pexels.com/photos/3148452/pexels-photo-3148452.jpeg?auto=compress&cs=tinysrgb&w=1200" class="w-full h-full object-cover" alt="Futebol 2">
        <div class="absolute inset-0 bg-gradient-to-t from-gray-950 via-gray-950/40 to-transparent flex flex-col justify-end p-6">
          <span class="bg-emerald-500/20 text-neon text-xs font-bold px-3 py-1 rounded-full w-fit mb-2 border border-emerald-500/40">BRASILEIRÃO & LIBERTADORES</span>
          <h2 class="text-2xl sm:text-4xl font-extrabold text-white">AS MELHORES ODDS DO MERCADO</h2>
          <p class="text-gray-300 text-sm sm:text-base">Cotações super turbinadas para os clássicos de hoje.</p>
        </div>
      </div>

      <!-- Banner 3 -->
      <div class="slide-item absolute inset-0">
        <img src="https://images.pexels.com/photos/1884574/pexels-photo-1884574.jpeg?auto=compress&cs=tinysrgb&w=1200" class="w-full h-full object-cover" alt="Futebol 3">
        <div class="absolute inset-0 bg-gradient-to-t from-gray-950 via-gray-950/40 to-transparent flex flex-col justify-end p-6">
          <span class="bg-emerald-500/20 text-neon text-xs font-bold px-3 py-1 rounded-full w-fit mb-2 border border-emerald-500/40">SAQUE RÁPIDO</span>
          <h2 class="text-2xl sm:text-4xl font-extrabold text-white">PAGAMENTO INSTANTÂNEO VIA PIX</h2>
          <p class="text-gray-300 text-sm sm:text-base">Ganhou, sacou! O dinheiro direto na sua conta em segundos.</p>
        </div>
      </div>

      <!-- Indicadores do Carrossel -->
      <div class="absolute bottom-3 right-4 flex gap-2 z-10" id="carouselIndicators">
        <span class="w-3 h-3 rounded-full bg-emerald-400 cursor-pointer"></span>
        <span class="w-3 h-3 rounded-full bg-gray-600 cursor-pointer"></span>
        <span class="w-3 h-3 rounded-full bg-gray-600 cursor-pointer"></span>
      </div>
    </div>
  </section>

  <!-- SEÇÃO DE VANTAGENS -->
  <section class="max-w-6xl mx-auto px-4 py-8">
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div class="bg-gray-900 border border-gray-800 p-5 rounded-xl flex items-center gap-4">
        <div class="w-12 h-12 rounded-lg bg-emerald-500/10 flex items-center justify-center text-neon text-2xl border border-emerald-500/30">
          <i class="fa-bolt fa-solid"></i>
        </div>
        <div>
          <h3 class="font-bold text-white">PIX Rápido</h3>
          <p class="text-xs text-gray-400">Depósitos e saques automatizados em instantes.</p>
        </div>
      </div>

      <div class="bg-gray-900 border border-gray-800 p-5 rounded-xl flex items-center gap-4">
        <div class="w-12 h-12 rounded-lg bg-emerald-500/10 flex items-center justify-center text-neon text-2xl border border-emerald-500/30">
          <i class="fa-shield-halved fa-solid"></i>
        </div>
        <div>
          <h3 class="font-bold text-white">Plataforma Segura</h3>
          <p class="text-xs text-gray-400">Proteção total aos seus dados e bilhetes.</p>
        </div>
      </div>

      <div class="bg-gray-900 border border-gray-800 p-5 rounded-xl flex items-center gap-4">
        <div class="w-12 h-12 rounded-lg bg-emerald-500/10 flex items-center justify-center text-neon text-2xl border border-emerald-500/30">
          <i class="fa-headset fa-solid"></i>
        </div>
        <div>
          <h3 class="font-bold text-white">Suporte 24/7</h3>
          <p class="text-xs text-gray-400">Atendimento pronto para tirar todas as dúvidas.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- CARD DE PRÓXIMAS PARTIDAS DISPONÍVEIS -->
  <section class="max-w-6xl mx-auto px-4 py-2">
    <div class="bg-gray-900 border border-gray-800 rounded-2xl p-5 shadow-xl">
      <div class="flex items-center justify-between mb-4">
        <h3 class="text-sm font-bold text-white flex items-center gap-2">
          <i class="fa-solid fa-calendar-days text-neon text-xs"></i> Próximas Partidas Disponíveis
        </h3>
        <!-- Botão de Atualizar reposicionado discretamente aqui no topo da seção -->
        <button onclick="carregarDadosComSkeleton()" class="px-3 py-1 text-xs font-semibold text-gray-300 bg-gray-950 border border-gray-800 hover:border-emerald-500/50 rounded-lg transition flex items-center gap-1.5">
          <i class="fa-solid fa-rotate text-neon text-[10px]"></i> Atualizar Lista
        </button>
      </div>

      <div id="container-proximos-jogos">
        <?php if (empty($proximos_jogos)): ?>
          <!-- ESTADO VAZIO CRIATIVO PARA PRÓXIMAS PARTIDAS -->
          <div class="text-center py-10 px-4 flex flex-col items-center justify-center bg-gray-950/60 rounded-xl border border-gray-800/60 my-2">
            <div class="w-12 h-12 rounded-full bg-emerald-500/10 flex items-center justify-center text-neon text-xl mb-3 border border-emerald-500/30 shadow-inner">
              <i class="fa-solid fa-calendar-xmark"></i>
            </div>
            <h4 class="text-white font-bold text-sm mb-1">Nenhum jogo agendado</h4>
            <p class="text-gray-400 text-xs max-w-sm mb-4">Ainda não há partidas abertas no sistema. Fique de olho ou entre em contato com o suporte para novas rodadas.</p>
            <button onclick="Toast.info('Aviso', 'As próximas partidas serão carregadas automaticamente assim que cadastradas.')" class="px-4 py-2 bg-gray-900 border border-emerald-500/40 text-neon font-semibold text-xs rounded-lg hover:bg-emerald-500/10 transition flex items-center gap-2">
              <i class="fa-solid fa-bell"></i> Avisar-me de Novidades
            </button>
          </div>
        <?php else: ?>
          <div class="space-y-2">
            <?php foreach ($proximos_jogos as $jogo): ?>
              <div class="bg-gray-950 border border-gray-800/80 rounded-xl px-3 py-2.5 flex items-center justify-between">
                <div class="flex items-center gap-2 w-2/5 justify-end">
                  <span class="font-medium text-xs text-right text-gray-300 truncate max-w-[120px] sm:max-w-xs"><?= htmlspecialchars($jogo['time_mandante']) ?></span>
                  <?php if (!empty($jogo['logo_mandante'])): ?>
                    <img src="<?= htmlspecialchars($jogo['logo_mandante']) ?>" class="w-6 h-6 rounded-full object-cover border border-gray-700 flex-shrink-0">
                  <?php endif; ?>
                </div>
                <div class="flex flex-col items-center px-2 flex-shrink-0">
                  <span class="text-[10px] font-extrabold text-neon">VS</span>
                  <span class="text-[9px] text-gray-400"><?= date('d/m/Y H:i', strtotime($jogo['data_hora'])) ?></span>
                </div>
                <div class="flex items-center gap-2 w-2/5 justify-start">
                  <?php if (!empty($jogo['logo_visitante'])): ?>
                    <img src="<?= htmlspecialchars($jogo['logo_visitante']) ?>" class="w-6 h-6 rounded-full object-cover border border-gray-700 flex-shrink-0">
                  <?php endif; ?>
                  <span class="font-medium text-xs text-left text-gray-300 truncate max-w-[120px] sm:max-w-xs"><?= htmlspecialchars($jogo['time_visitante']) ?></span>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </section>

  <!-- CARD DE ÚLTIMOS RESULTADOS AO VIVO -->
  <section class="max-w-6xl mx-auto px-4 py-2">
    <div class="bg-gray-900 border border-gray-800 rounded-2xl p-5 shadow-xl">
      <div class="flex items-center justify-between mb-4">
        <h3 class="text-sm font-bold text-white flex items-center gap-2">
          <i class="fa-solid fa-clock-rotate-left text-neon text-xs"></i> Últimos Resultados Ao Vivo
        </h3>
      </div>

      <div id="container-ultimos-jogos">
        <?php if (empty($ultimos_resultados)): ?>
          <!-- ESTADO VAZIO CRIATIVO PARA ÚLTIMOS RESULTADOS -->
          <div class="text-center py-10 px-4 flex flex-col items-center justify-center bg-gray-950/60 rounded-xl border border-gray-800/60 my-2">
            <div class="w-12 h-12 rounded-full bg-emerald-500/10 flex items-center justify-center text-neon text-xl mb-3 border border-emerald-500/30 shadow-inner">
              <i class="fa-solid fa-futbol"></i>
            </div>
            <h4 class="text-white font-bold text-sm mb-1">Nenhum resultado recente</h4>
            <p class="text-gray-400 text-xs max-w-sm mb-4">Os placares dos últimos confrontos encerrados aparecerão aqui automaticamente.</p>
            <button onclick="carregarDadosComSkeleton()" class="px-4 py-2 bg-gray-900 border border-emerald-500/40 text-neon font-semibold text-xs rounded-lg hover:bg-emerald-500/10 transition flex items-center gap-2">
              <i class="fa-solid fa-rotate"></i> Atualizar Dados
            </button>
          </div>
        <?php else: ?>
          <div class="space-y-2">
            <?php foreach ($ultimos_resultados as $jogo): ?>
              <div class="bg-gray-950 border border-gray-800/80 rounded-xl px-3 py-2.5 flex items-center justify-between">
                <div class="flex items-center gap-2 w-2/5 justify-end">
                  <span class="font-medium text-xs text-right text-gray-300 truncate max-w-[120px] sm:max-w-xs"><?= htmlspecialchars($jogo['time_mandante']) ?></span>
                  <?php if (!empty($jogo['logo_mandante'])): ?>
                    <img src="<?= htmlspecialchars($jogo['logo_mandante']) ?>" class="w-6 h-6 rounded-full object-cover border border-gray-700 flex-shrink-0">
                  <?php endif; ?>
                </div>
                <div class="px-2.5 py-0.5 bg-gray-900 border border-emerald-500/30 rounded-lg text-neon font-bold text-xs tracking-wider shadow-inner flex-shrink-0">
                  <?= $jogo['gols_mandante'] ?? '0' ?> x <?= $jogo['gols_visitante'] ?? '0' ?>
                </div>
                <div class="flex items-center gap-2 w-2/5 justify-start">
                  <?php if (!empty($jogo['logo_visitante'])): ?>
                    <img src="<?= htmlspecialchars($jogo['logo_visitante']) ?>" class="w-6 h-6 rounded-full object-cover border border-gray-700 flex-shrink-0">
                  <?php endif; ?>
                  <span class="font-medium text-xs text-left text-gray-300 truncate max-w-[120px] sm:max-w-xs"><?= htmlspecialchars($jogo['time_visitante']) ?></span>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </section>

  <!-- CTA PRINCIPAL -->
  <section class="max-w-6xl mx-auto px-4 py-8 text-center">
    <div class="bg-gradient-to-r from-emerald-950 via-gray-900 to-gray-950 border border-emerald-500/30 rounded-2xl p-8 shadow-neon">
      <h3 class="text-2xl sm:text-3xl font-extrabold text-white mb-2">Pronto para dar seu palpite?</h3>
      <p class="text-gray-400 text-sm max-w-xl mx-auto mb-6">Crie sua conta agora mesmo e comece a apostar nos jogos do seu time de coração!</p>
      <button onclick="openModal('registerModal')" class="px-8 py-3 bg-neon font-extrabold text-black rounded-xl hover:bg-emerald-400 transition shadow-lg transform hover:-translate-y-0.5">
        CRIAR CONTA AGORA
      </button>
    </div>
  </section>

  <!-- FOOTER / FALE CONOSCO -->
  <footer class="border-t border-gray-800 bg-gray-950 pt-10 pb-6 text-gray-400 text-sm">
    <div class="max-w-6xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
      <div>
        <div class="flex items-center gap-2 mb-3">
          <i class="fa-solid fa-futbol text-xl text-neon"></i>
          <span class="text-lg font-extrabold tracking-wider text-white">ARENA<span class="text-neon">BET</span></span>
        </div>
        <p class="text-xs text-gray-500 leading-relaxed">A sua plataforma de apostas esportivas com cotações justas e pagamentos via PIX instantâneos.</p>
      </div>
      <div>
        <h4 class="text-white font-bold mb-3 text-sm tracking-wide">Fale Conosco</h4>
        <ul class="space-y-2 text-xs">
          <li>
            <a href="https://wa.me/5585991302069?text=Olá,%20gostaria%20de%20suporte%20na%20ArenaBet." target="_blank" class="flex items-center gap-2 hover:text-neon transition">
              <i class="fa-brands fa-whatsapp text-neon text-base"></i> WhatsApp: (85) 99130-2069
            </a>
          </li>
          <li>
            <a href="mailto:suporte@arenabet.com" class="flex items-center gap-2 hover:text-neon transition">
              <i class="fa-solid fa-envelope text-neon"></i> E-mail: suporte@arenabet.com
            </a>
          </li>
        </ul>
      </div>
      <div>
        <h4 class="text-white font-bold mb-3 text-sm tracking-wide">Aviso Legal</h4>
        <p class="text-xs text-gray-500 leading-relaxed">Proibido para menores de 18 anos. Jogue com responsabilidade. As apostas esportivas envolvem riscos financeiros.</p>
      </div>
    </div>
    <div class="border-t border-gray-900 pt-4 text-center text-xs text-gray-600">
      <p>© 2026 ArenaBet - Todos os direitos reservados.</p>
    </div>
  </footer>

  <!-- MODAL DE LOGIN -->
  <div id="loginModal" class="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 hidden items-center justify-center p-4">
    <div class="bg-gray-900 border border-emerald-500/40 rounded-2xl w-full max-w-md p-6 relative shadow-2xl">
      <button onclick="closeModal('loginModal')" class="absolute top-4 right-4 text-gray-400 hover:text-white">
        <i class="fa-solid fa-xmark text-xl"></i>
      </button>
      <div class="text-center mb-6">
        <i class="fa-solid fa-right-to-bracket text-3xl text-neon mb-2"></i>
        <h3 class="text-xl font-bold text-white">Entrar na ArenaBet</h3>
        <p class="text-xs text-gray-400">Digite seus dados para acessar sua conta</p>
      </div>
      <form onsubmit="handleLogin(event)" class="space-y-4">
        <div>
          <label class="block text-xs font-medium text-gray-300 mb-1">E-mail</label>
          <input type="email" required class="w-full bg-gray-950 border border-gray-800 rounded-lg p-3 text-white focus:border-emerald-500 focus:outline-none text-sm" placeholder="seuemail@email.com">
        </div>
        <div>
          <label class="block text-xs font-medium text-gray-300 mb-1">Senha</label>
          <input type="password" required class="w-full bg-gray-950 border border-gray-800 rounded-lg p-3 text-white focus:border-emerald-500 focus:outline-none text-sm" placeholder="••••••••">
        </div>
        <button type="submit" class="w-full bg-neon text-black font-bold py-3 rounded-lg hover:bg-emerald-400 transition">
          ENTRAR
        </button>
      </form>
    </div>
  </div>

  <!-- MODAL DE CADASTRO -->
  <div id="registerModal" class="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 hidden items-center justify-center p-4">
    <div class="bg-gray-900 border border-emerald-500/40 rounded-2xl w-full max-w-md p-6 relative shadow-2xl">
      <button onclick="closeModal('registerModal')" class="absolute top-4 right-4 text-gray-400 hover:text-white">
        <i class="fa-solid fa-xmark text-xl"></i>
      </button>
      <div class="text-center mb-6">
        <i class="fa-solid fa-user-plus text-3xl text-neon mb-2"></i>
        <h3 class="text-xl font-bold text-white">Criar Nova Conta</h3>
        <p class="text-xs text-gray-400">Preencha os campos para se cadastrar</p>
      </div>
      <form onsubmit="handleRegister(event)" class="space-y-4">
        <div>
          <label class="block text-xs font-medium text-gray-300 mb-1">Nome Completo</label>
          <input type="text" required class="w-full bg-gray-950 border border-gray-800 rounded-lg p-3 text-white focus:border-emerald-500 focus:outline-none text-sm" placeholder="Seu Nome">
        </div>
        <div>
          <label class="block text-xs font-medium text-gray-300 mb-1">E-mail</label>
          <input type="email" required class="w-full bg-gray-950 border border-gray-800 rounded-lg p-3 text-sm" placeholder="seuemail@email.com">
        </div>
        <div>
          <label class="block text-xs font-medium text-gray-300 mb-1">Senha</label>
          <input type="password" required class="w-full bg-gray-950 border border-gray-800 rounded-lg p-3 text-white focus:border-emerald-500 focus:outline-none text-sm" placeholder="••••••••">
        </div>
        <button type="submit" class="w-full bg-neon text-black font-bold py-3 rounded-lg hover:bg-emerald-400 transition">
          CADASTRAR E ENTRAR
        </button>
      </form>
    </div>
  </div>

  <!-- MOTOR DA BIBLIOTECA DE TOASTS E SKELETON LOADER -->
  <script>
    const Toast = {
      show(title, message, type = 'info', duration = 4000) {
        const container = document.getElementById('toast-container');
        if (!container) return;

        const icons = {
          success: 'fa-circle-check',
          error: 'fa-circle-xmark',
          warning: 'fa-triangle-exclamation',
          info: 'fa-circle-info'
        };

        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        
        toast.innerHTML = `
          <i class="fa-solid ${icons[type] || icons.info} toast-icon"></i>
          <div class="toast-content">
            <div class="toast-title">${title}</div>
            ${message ? `<div class="toast-message">${message}</div>` : ''}
          </div>
          <button class="toast-close" onclick="this.parentElement.remove()">&times;</button>
          <div class="toast-progress"></div>
        `;

        container.appendChild(toast);
        setTimeout(() => toast.classList.add('show'), 10);

        const progress = toast.querySelector('.toast-progress');
        progress.style.transition = `transform ${duration}ms linear`;
        setTimeout(() => progress.style.transform = 'scaleX(0)', 20);

        setTimeout(() => {
          toast.classList.remove('show');
          setTimeout(() => toast.remove(), 350);
        }, duration);
      },

      success(title, message, duration) { this.show(title, message, 'success', duration); },
      error(title, message, duration) { this.show(title, message, 'error', duration); },
      warning(title, message, duration) { this.show(title, message, 'warning', duration); },
      info(title, message, duration) { this.show(title, message, 'info', duration); }
    };

    function carregarDadosComSkeleton() {
      const containerProx = document.getElementById('container-proximos-jogos');
      const containerUlt = document.getElementById('container-ultimos-jogos');

      const skeletonHTML = `
        <div class="space-y-2">
          <div class="skeleton h-12 w-full"></div>
          <div class="skeleton h-12 w-full"></div>
          <div class="skeleton h-12 w-full"></div>
        </div>
      `;

      if(containerProx) containerProx.innerHTML = skeletonHTML;
      if(containerUlt) containerUlt.innerHTML = skeletonHTML;
      Toast.info('Atualizando...', 'Buscando novas partidas e cotações.');

      setTimeout(() => {
        location.reload();
      }, 1200);
    }
  </script>

  <!-- SCRIPT DO CARROSSEL E MODAIS -->
  <script>
    let currentSlide = 0;
    const slides = document.querySelectorAll('.slide-item');
    const indicators = document.querySelectorAll('#carouselIndicators span');

    function showSlide(index) {
      if(slides.length === 0) return;
      slides.forEach((slide, i) => {
        slide.classList.remove('active');
        if(indicators[i]) indicators[i].classList.replace('bg-emerald-400', 'bg-gray-600');
      });
      slides[index].classList.add('active');
      if(indicators[index]) indicators[index].classList.replace('bg-gray-600', 'bg-emerald-400');
    }

    if(slides.length > 0) {
      setInterval(() => {
        currentSlide = (currentSlide + 1) % slides.length;
        showSlide(currentSlide);
      }, 2000);
    }

    function openModal(id) {
      document.getElementById(id).classList.remove('hidden');
      document.getElementById(id).classList.add('flex');
    }
    function closeModal(id) {
      document.getElementById(id).classList.add('hidden');
      document.getElementById(id).classList.remove('flex');
    }

    function handleLogin(e) {
      e.preventDefault();
      Toast.success('Login Realizado!', 'Redirecionando para sua área...');
      setTimeout(() => {
        window.location.href = 'cliente/index.php';
      }, 1200);
    }

    function handleRegister(e) {
      e.preventDefault();
      Toast.success('Conta Criada com Sucesso!', 'Bem-vindo(a) à ArenaBet.');
      setTimeout(() => {
        window.location.href = 'cliente/index.php';
      }, 1200);
    }
  </script>
</body>
</html>