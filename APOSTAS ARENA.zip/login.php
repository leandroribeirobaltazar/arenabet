<?php
@include_once 'conexao.php';
session_start();

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';

    if (!empty($email) && !empty($senha) && isset($pdo)) {
        try {
            $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = ?");
            $stmt->execute([$email]);
            $usuario = $stmt->fetch();

            // Verifica se o usuário existe e se a senha confere
            if ($usuario && password_verify($senha, $usuario['senha'])) {
                // Grava as informações reais na sessão
                $_SESSION['usuario_id'] = $usuario['id'];
                $_SESSION['usuario_nome'] = $usuario['nome'];

                header("Location: cliente/index.php");
                exit;
            } else {
                $erro = "E-mail ou senha incorretos!";
            }
        } catch (Exception $e) {
            $erro = "Erro ao processar o login: " . $e->getMessage();
        }
    } else {
        $erro = "Preencha todos os campos!";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login - ArenaBet</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    :root { --neon-green: #00FF66; --neon-green-glow: rgba(0, 255, 102, 0.35); --bg-dark: #07090e; }
    body { background-color: var(--bg-dark); color: #ffffff; font-family: 'Segoe UI', sans-serif; }
    .text-neon { color: var(--neon-green); text-shadow: 0 0 10px var(--neon-green-glow); }
    .bg-neon { background-color: var(--neon-green); color: #000000; }
  </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4">
  <div class="bg-gray-900 border border-emerald-500/40 rounded-2xl w-full max-w-md p-8 shadow-2xl">
    
    <div class="text-center mb-6">
      <a href="index.php" class="inline-block mb-2">
        <i class="fa-solid fa-futbol text-3xl text-neon"></i>
      </a>
      <h3 class="text-2xl font-extrabold text-white">Acesse sua Conta</h3>
      <p class="text-xs text-gray-400">Entre para fazer seus palpites na ArenaBet</p>
    </div>

    <?php if ($erro): ?>
      <div class="bg-red-500/20 border border-red-500/50 text-red-300 text-xs p-3 rounded-lg mb-4 text-center">
        <?= $erro ?>
      </div>
    <?php endif; ?>

    <form method="POST" class="space-y-4">
      <div>
        <label class="block text-xs font-medium text-gray-300 mb-1">E-mail</label>
        <input type="email" name="email" required class="w-full bg-gray-950 border border-gray-800 rounded-lg p-3 text-white focus:border-emerald-500 focus:outline-none text-sm" placeholder="seu@email.com">
      </div>
      <div>
        <label class="block text-xs font-medium text-gray-300 mb-1">Senha</label>
        <input type="password" name="senha" required class="w-full bg-gray-950 border border-gray-800 rounded-lg p-3 text-white focus:border-emerald-500 focus:outline-none text-sm" placeholder="••••••••">
      </div>
      <button type="submit" class="w-full bg-neon font-bold py-3 rounded-lg hover:bg-emerald-400 transition shadow-lg">
        ENTRAR
      </button>
    </form>

    <div class="text-center mt-6 text-xs text-gray-400">
      Não tem uma conta? <a href="cadastro.php" class="text-neon font-bold hover:underline">Cadastre-se</a>
    </div>
    
    <div class="text-center mt-3">
      <a href="index.php" class="text-xs text-gray-500 hover:text-gray-300"><i class="fa-solid fa-arrow-left"></i> Voltar ao início</a>
    </div>

  </div>
</body>
</html>