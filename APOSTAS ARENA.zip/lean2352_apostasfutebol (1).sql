-- phpMyAdmin SQL Dump
-- version 5.2.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geração: 05/11/2026 às 12:11
-- Versão do servidor: 5.7.44-48
-- Versão do PHP: 8.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `lean2352_apostasfutebol`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `apostas`
--

CREATE TABLE `apostas` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `jogo_id` int(11) NOT NULL,
  `tipo_aposta` varchar(20) NOT NULL,
  `odd` decimal(5,2) NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `possivel_retorno` decimal(10,2) NOT NULL,
  `status` varchar(20) DEFAULT 'Pendente',
  `criado_em` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ocultar_cliente` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Despejando dados para a tabela `apostas`
--

INSERT INTO `apostas` (`id`, `usuario_id`, `jogo_id`, `tipo_aposta`, `odd`, `valor`, `possivel_retorno`, `status`, `criado_em`, `ocultar_cliente`) VALUES
(1, 1, 1, 'Casa (1)', 2.00, 50.00, 100.00, 'Pendente', '2026-11-05 04:02:43', 0),
(2, 1, 4, 'Fora (2)', 3.50, 50.00, 175.00, 'Perdida', '2026-11-05 04:07:48', 0),
(3, 1, 8, 'Fora (2)', 3.50, 10.00, 35.00, 'Pendente', '2026-11-05 12:27:37', 0),
(4, 1, 7, 'Fora (2)', 3.50, 10.00, 35.00, 'Pendente', '2026-11-05 12:27:46', 0),
(5, 1, 11, 'Casa (1)', 2.00, 10.00, 20.00, 'Pendente', '2026-11-05 12:27:56', 0),
(6, 1, 10, 'Fora (2)', 3.50, 10.00, 35.00, 'Pendente', '2026-11-05 12:28:00', 0),
(7, 1, 20, 'Empate (X)', 3.20, 10.00, 32.00, 'Pendente', '2026-11-05 13:36:54', 0),
(8, 2, 1, 'Casa (1)', 2.00, 5.00, 10.00, 'Pendente', '2026-11-05 14:38:29', 0),
(9, 2, 8, 'Empate (X)', 3.20, 5.00, 16.00, 'Pendente', '2026-11-05 14:38:41', 0),
(10, 2, 7, 'Casa (1)', 2.00, 5.00, 10.00, 'Pendente', '2026-11-05 14:38:51', 0),
(11, 2, 7, 'Casa (1)', 2.00, 5.00, 10.00, 'Pendente', '2026-11-05 14:39:15', 0),
(12, 1, 21, 'Kaio Jorge', 2.50, 100.00, 250.00, 'Pendente', '2026-11-05 14:59:31', 0),
(13, 2, 21, 'Kaio Jorge', 2.50, 10.00, 25.00, 'Pendente', '2026-11-05 15:01:29', 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `depositos_pix`
--

CREATE TABLE `depositos_pix` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `usuario_nome` varchar(100) NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `status` varchar(50) DEFAULT 'Pendente',
  `data_hora` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Despejando dados para a tabela `depositos_pix`
--

INSERT INTO `depositos_pix` (`id`, `usuario_id`, `usuario_nome`, `valor`, `status`, `data_hora`) VALUES
(5, 1, 'Leandro Ribeiro', 10000.00, 'Aprovado', '2026-11-05 04:00:39'),
(6, 2, 'Cliente ', 50.00, 'Aprovado', '2026-11-05 14:34:50'),
(7, 1, 'Leandro Ribeiro', 50.00, 'Aprovado', '2026-11-05 14:36:03'),
(8, 1, 'Leandro Ribeiro', 20.00, 'Aprovado', '2026-11-05 14:42:38'),
(10, 1, 'Leandro Ribeiro', 20.00, 'Aprovado', '2026-11-05 14:53:10'),
(11, 1, 'Leandro Ribeiro', 20.00, 'Aprovado', '2026-11-05 14:54:29'),
(12, 1, 'Leandro Ribeiro', 20.00, 'Aprovado', '2026-11-05 14:55:41'),
(13, 1, 'Leandro Ribeiro', 20.00, 'Aprovado', '2026-11-05 14:58:45');

-- --------------------------------------------------------

--
-- Estrutura para tabela `jogos`
--

CREATE TABLE `jogos` (
  `id` int(11) NOT NULL,
  `time_mandante` varchar(100) NOT NULL,
  `time_visitante` varchar(100) NOT NULL,
  `logo_mandante` varchar(255) DEFAULT NULL,
  `logo_visitante` varchar(255) DEFAULT NULL,
  `odd_1` decimal(5,2) NOT NULL DEFAULT '1.00',
  `odd_x` decimal(5,2) NOT NULL DEFAULT '1.00',
  `odd_2` decimal(5,2) NOT NULL DEFAULT '1.00',
  `data_hora` datetime NOT NULL,
  `status` enum('aberto','encerrado') DEFAULT 'aberto',
  `criado_em` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `gols_mandante` int(11) DEFAULT '0',
  `gols_visitante` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Despejando dados para a tabela `jogos`
--

INSERT INTO `jogos` (`id`, `time_mandante`, `time_visitante`, `logo_mandante`, `logo_visitante`, `odd_1`, `odd_x`, `odd_2`, `data_hora`, `status`, `criado_em`, `gols_mandante`, `gols_visitante`) VALUES
(1, 'PAL', 'REM', 'uploads/escudos/mandante_6aebfdbc93206.webp', 'uploads/escudos/visitante_6aebfdbc93302.webp', 2.00, 3.20, 3.50, '2026-11-05 19:30:00', 'aberto', '2026-11-05 03:53:32', 0, 0),
(4, 'FLA', 'GRE', 'uploads/escudos/mandante_6aec0105edb0a.webp', 'uploads/escudos/visitante_6aec0105edbf4.webp', 2.00, 3.20, 3.50, '2026-11-04 19:30:00', 'encerrado', '2026-11-05 04:07:33', 3, 1),
(8, 'VIT', 'FLU', 'uploads/escudos/mandante_6aec02cf99e12.webp', 'uploads/escudos/visitante_6aec02cf99f3c.webp', 2.00, 3.20, 3.50, '2026-11-05 20:00:00', 'aberto', '2026-11-05 04:15:11', 0, 0),
(9, 'SAO', 'COR', 'uploads/escudos/mandante_6aec07e65ae7c.webp', 'uploads/escudos/visitante_6aec07e65af7c.webp', 2.00, 3.20, 3.50, '2026-11-04 19:30:00', 'encerrado', '2026-11-05 04:36:54', 0, 0),
(10, 'CHA', 'VAS', 'uploads/escudos/mandante_6aec0b7609210.webp', 'uploads/escudos/visitante_6aec0b7609586.webp', 2.00, 3.20, 3.50, '2026-11-14 20:30:00', 'aberto', '2026-11-05 04:52:06', 0, 0),
(11, 'MIR', 'ATL', 'uploads/escudos/mandante_6aec0c84df649.webp', 'uploads/escudos/visitante_6aec0c84df777.webp', 2.00, 3.20, 3.50, '2026-11-14 18:30:00', 'aberto', '2026-11-05 04:56:36', 0, 0),
(12, 'COR', 'SAN', 'uploads/escudos/mandante_6aec7c9a20e39.webp', 'uploads/escudos/visitante_6aec7c9a20f51.webp', 1.50, 2.20, 2.50, '2026-11-18 19:30:00', 'aberto', '2026-11-05 12:54:50', 0, 0),
(13, 'REM', 'CHA', 'uploads/escudos/mandante_6aec7cd3911c4.webp', 'uploads/escudos/visitante_6aec7cd391328.webp', 2.00, 3.20, 3.50, '2026-11-18 20:00:00', 'aberto', '2026-11-05 12:55:47', 0, 0),
(14, 'FLA', 'CAP', 'uploads/escudos/mandante_6aec7cf694551.webp', 'uploads/escudos/visitante_6aec7cf694669.webp', 2.00, 3.20, 3.50, '2026-11-18 20:30:00', 'aberto', '2026-11-05 12:56:22', 0, 0),
(15, 'CRU', 'PAL', 'uploads/escudos/mandante_6aec7d11b6aa5.webp', 'uploads/escudos/visitante_6aec7d11b6bd2.webp', 2.00, 3.20, 3.50, '2026-11-18 20:30:00', 'aberto', '2026-11-05 12:56:49', 0, 0),
(16, 'COR', 'BOT', 'uploads/escudos/mandante_6aec7d280ac98.webp', 'uploads/escudos/visitante_6aec7d280ae0a.webp', 2.00, 3.20, 3.50, '2026-11-18 21:30:00', 'aberto', '2026-11-05 12:57:12', 0, 0),
(17, 'GRE', 'BAH', 'uploads/escudos/mandante_6aec7d61b13a0.webp', 'uploads/escudos/visitante_6aec7d61b14b8.webp', 2.00, 3.20, 3.50, '2026-11-18 21:30:00', 'aberto', '2026-11-05 12:58:09', 0, 0),
(18, 'VAS', 'INT', 'uploads/escudos/mandante_6aec7d7d13693.webp', 'uploads/escudos/visitante_6aec7d7d137a2.webp', 2.00, 3.20, 3.50, '2026-11-19 19:30:00', 'aberto', '2026-11-05 12:58:37', 0, 0),
(19, 'VIT', 'BRAG', 'uploads/escudos/mandante_6aec7dadc3ba2.webp', 'uploads/escudos/visitante_6aec7dadc3cc6.webp', 2.00, 3.20, 3.50, '2026-11-19 19:30:00', 'aberto', '2026-11-05 12:59:25', 0, 0),
(20, 'SAO', 'FLU', 'uploads/escudos/mandante_6aec7dceead21.webp', 'uploads/escudos/visitante_6aec7dceeae23.webp', 2.00, 3.20, 3.50, '2026-11-19 21:30:00', 'aberto', '2026-11-05 12:59:58', 0, 0),
(21, 'CRU', 'BAH', 'uploads/escudos/mandante_6aec984a73f0b.webp', 'uploads/escudos/visitante_6aec984a74179.webp', 2.00, 3.20, 3.50, '2026-11-05 21:30:00', 'aberto', '2026-11-05 14:52:58', 0, 0);

-- --------------------------------------------------------

--
-- Estrutura para tabela `mercados_extras`
--

CREATE TABLE `mercados_extras` (
  `id` int(11) NOT NULL,
  `jogo_id` int(11) NOT NULL,
  `pergunta` varchar(255) NOT NULL,
  `opcao` varchar(150) NOT NULL,
  `odd` decimal(5,2) NOT NULL DEFAULT '2.00',
  `status` enum('aberto','encerrado') DEFAULT 'aberto'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Despejando dados para a tabela `mercados_extras`
--

INSERT INTO `mercados_extras` (`id`, `jogo_id`, `pergunta`, `opcao`, `odd`, `status`) VALUES
(1, 21, 'Quem vai fazer o gol Cruzeiro?', 'Kaio Jorge', 2.50, 'aberto'),
(2, 1, 'Quem vai fazer 1° Gol PAL?', 'Flaco Lopez', 2.50, 'aberto'),
(3, 8, 'Vitoria vai fazer o 1° gol?', 'SIM', 2.50, 'aberto'),
(4, 11, 'Mirassol vai fazer o 1° gol?', 'SIM (ODD)', 2.50, 'aberto'),
(5, 10, 'CHA Tem Alguem Expulso?', 'SIM (ODD)', 2.50, 'aberto'),
(6, 10, 'CHA Tem + 6 Escanteios?', 'SIM (ODD)', 2.50, 'aberto'),
(7, 12, 'Coxa faz gol de Penal?', 'SIM (ODD)', 3.50, 'aberto');

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `saldo` decimal(10,2) DEFAULT '0.00',
  `criado_em` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `email`, `senha`, `saldo`, `criado_em`) VALUES
(1, 'Leandro Ribeiro', 'leandro@gmail.com', '$2y$10$4w54ulv9ppiuO2gb4yKbiu9HhvnLTsouNbP4qwI66Aq9JYg2SsBQa', 550.00, '2026-11-05 04:00:29'),
(2, 'Cliente ', 'cliente@gmail.com', '$2y$10$55e6BEBGBySdyf8ivC/r9uPybkKyS51nz7K9VulcmX3JBy9vn6axG', 90.00, '2026-11-05 14:19:32');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `apostas`
--
ALTER TABLE `apostas`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `depositos_pix`
--
ALTER TABLE `depositos_pix`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `jogos`
--
ALTER TABLE `jogos`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `mercados_extras`
--
ALTER TABLE `mercados_extras`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jogo_id` (`jogo_id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `apostas`
--
ALTER TABLE `apostas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de tabela `depositos_pix`
--
ALTER TABLE `depositos_pix`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de tabela `jogos`
--
ALTER TABLE `jogos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de tabela `mercados_extras`
--
ALTER TABLE `mercados_extras`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `mercados_extras`
--
ALTER TABLE `mercados_extras`
  ADD CONSTRAINT `mercados_extras_ibfk_1` FOREIGN KEY (`jogo_id`) REFERENCES `jogos` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
