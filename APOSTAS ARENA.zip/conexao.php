<?php
$host = "localhost";
$db   = "*******";
$user = "*******";
$pass = "*******"; // Substitua pela sua senha real do banco

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
} catch (PDOException $e) {
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
        header('Content-Type: application/json');
        echo json_encode(["status" => "error", "message" => "Erro de conexão: " . $e->getMessage()]);
        exit;
    }
    die("Erro ao conectar com o banco de dados.");
}
?>