<?php
@include_once '../conexao.php';
session_start();

$admin_user = 'baltazar';
$admin_pass = '02579100';
$erro_login = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fazer_login'])) {
    $u = $_POST['usuario'] ?? '';
    $s = $_POST['senha'] ?? '';
    if ($u === $admin_user && $s === $admin_pass) {
        $_SESSION['admin_logado'] = true;
        header("Location: index.php");
        exit;
    } else {
        $erro_login = "Usuário ou senha incorretos!";
    }
}

if (isset($_GET['logout'])) {
    unset($_SESSION['admin_logado']);
    header("Location: index.php");
    exit;
}

if (!isset($_SESSION['admin_logado']) || $_SESSION['admin_logado'] !== true):
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Administrativo - ArenaBet</title>
  <meta name="keywords" content="arena apostas esportivas, aposta, odds, futebol, painel admin, lucros">
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    :root { --neon-green: #00FF66; --bg-dark: #07090e; }
    body { background-color: var(--bg-dark); color: #fff; font-family: 'Segoe UI', sans-serif; }
    .text-neon { color: var(--neon-green); text-shadow: 0 0 10px rgba(0, 255, 102, 0.35); }
    .bg-neon { background-color: var(--neon-green); color: #000; }
  </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4">
  <div class="bg-gray-900 border border-emerald-500/40 rounded-2xl w-full max-w-md p-8 shadow-2xl">
    <div class="text-center mb-6">
      <i class="fa-solid fa-lock text-3xl text-neon mb-2"></i>
      <h3 class="text-2xl font-extrabold text-white">Painel Restrito</h3>
      <p class="text-xs text-gray-400">Identifique-se para acessar o administrador</p>
    </div>
    <?php if ($erro_login): ?>
      <div class="bg-red-500/20 border border-red-500/50 text-red-300 text-xs p-3 rounded-lg mb-4 text-center"><?= $erro_login ?></div>
    <?php endif; ?>
    <form method="POST" class="space-y-4">
      <input type="hidden" name="fazer_login" value="1">
      <div>
        <label class="block text-xs font-medium text-gray-300 mb-1">Usuário</label>
        <input type="text" name="usuario" required class="w-full bg-gray-950 border border-gray-800 rounded-lg p-3 text-white focus:border-emerald-500 focus:outline-none text-sm">
      </div>
      <div>
        <label class="block text-xs font-medium text-gray-300 mb-1">Senha</label>
        <input type="password" name="senha" required class="w-full bg-gray-950 border border-gray-800 rounded-lg p-3 text-white focus:border-emerald-500 focus:outline-none text-sm">
      </div>
      <button type="submit" class="w-full bg-neon font-bold py-3 rounded-lg hover:bg-emerald-400 transition shadow-lg">ENTRAR NO PAINEL</button>
    </form>
    <div class="text-center mt-4"><a href="../index.php" class="text-xs text-gray-500 hover:text-gray-300"><i class="fa-solid fa-arrow-left"></i> Voltar ao site</a></div>
  </div>
</body>
</html>
<?php 
exit;
endif; 

$mensagem = $_SESSION['mensagem_admin'] ?? '';
unset($_SESSION['mensagem_admin']);

$erro = $_SESSION['erro_admin'] ?? '';
unset($_SESSION['erro_admin']);

// Garante que a tabela de mercados extras existe no banco
if (isset($pdo)) {
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS `mercados_extras` (
          `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
          `jogo_id` INT(11) NOT NULL,
          `pergunta` VARCHAR(255) NOT NULL,
          `opcao` VARCHAR(150) NOT NULL,
          `odd` DECIMAL(5,2) NOT NULL DEFAULT '2.00',
          `status` ENUM('aberto', 'encerrado') DEFAULT 'aberto'
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
    } catch (Exception $e) {}
}

// Aprovação de Depósito PIX
if (isset($_GET['aprovar_pix']) && isset($pdo)) {
    $deposito_id = intval($_GET['aprovar_pix']);
    try {
        $stmt = $pdo->prepare("SELECT * FROM depositos_pix WHERE id = ? AND status = 'Pendente'");
        $stmt->execute([$deposito_id]);
        $dep = $stmt->fetch();

        if ($dep) {
            $pdo->prepare("UPDATE depositos_pix SET status = 'Aprovado' WHERE id = ?")->execute([$deposito_id]);
            $pdo->prepare("UPDATE usuarios SET saldo = saldo + ? WHERE id = ?")->execute([$dep['valor'], $dep['usuario_id']]);
            $_SESSION['mensagem_admin'] = "Depósito de R$ " . number_format($dep['valor'], 2, ',', '.') . " aprovado e saldo creditado!";
        }
    } catch (Exception $e) {
        $_SESSION['erro_admin'] = "Erro ao aprovar depósito: " . $e->getMessage();
    }
    header("Location: index.php");
    exit;
}

// Encerramento de Jogo com Placar Real e Pagamento de Prêmios
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['encerrar_partida'])) {
    $jogo_id = intval($_POST['jogo_id'] ?? 0);
    $gols_mandante = intval($_POST['gols_mandante'] ?? 0);
    $gols_visitante = intval($_POST['gols_visitante'] ?? 0);
    $vencedor = trim($_POST['vencedor'] ?? '');

    try {
        $pdo->beginTransaction();

        $stmt = $pdo->prepare("UPDATE jogos SET status = 'encerrado', gols_mandante = ?, gols_visitante = ? WHERE id = ?");
        $stmt->execute([$gols_mandante, $gols_visitante, $jogo_id]);

        $stmt = $pdo->prepare("SELECT * FROM apostas WHERE jogo_id = ? AND status = 'Pendente'");
        $stmt->execute([$jogo_id]);
        $apostas = $stmt->fetchAll();

        $total_pagamentos = 0;
        foreach ($apostas as $aposta) {
            if ($aposta['tipo_aposta'] === $vencedor) {
                $pdo->prepare("UPDATE apostas SET status = 'Ganha' WHERE id = ?")->execute([$aposta['id']]);
                $pdo->prepare("UPDATE usuarios SET saldo = saldo + ? WHERE id = ?")->execute([$aposta['possivel_retorno'], $aposta['usuario_id']]);
                $total_pagamentos++;
            } else {
                $pdo->prepare("UPDATE apostas SET status = 'Perdida' WHERE id = ?")->execute([$aposta['id']]);
            }
        }

        $pdo->commit();
        $_SESSION['mensagem_admin'] = "Jogo encerrado! Placar: $gols_mandante x $gols_visitante. Vencedor: $vencedor. $total_pagamentos apostas premiadas pagas!";
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['erro_admin'] = "Erro ao encerrar jogo: " . $e->getMessage();
    }
    header("Location: index.php");
    exit;
}

// Cadastro de Novo Jogo + Mercado Extra (Quem vai fazer o gol?)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cadastrar_jogo'])) {
    $time_mandante = $_POST['time_mandante'] ?? '';
    $time_visitante = $_POST['time_visitante'] ?? '';
    $odd_1 = floatval($_POST['odd_1'] ?? 1.00);
    $odd_x = floatval($_POST['odd_x'] ?? 1.00);
    $odd_2 = floatval($_POST['odd_2'] ?? 1.00);
    $data_hora = $_POST['data_hora'] ?? date('Y-m-d H:i:s');

    // Dados do mercado extra (Ex: Quem vai fazer o gol?)
    $pergunta_extra = trim($_POST['pergunta_extra'] ?? '');
    $opcao_extra = trim($_POST['opcao_extra'] ?? '');
    $odd_extra = floatval($_POST['odd_extra'] ?? 0.00);

    $uploadDir = '../uploads/escudos/';
    if (!is_dir($uploadDir)) { @mkdir($uploadDir, 0755, true); }

    $logo_mandante = '';
    if (isset($_FILES['logo_mandante']) && $_FILES['logo_mandante']['error'] === UPLOAD_ERR_OK) {
        $filename = uniqid('mandante_') . '.webp';
        @move_uploaded_file($_FILES['logo_mandante']['tmp_name'], $uploadDir . $filename);
        $logo_mandante = 'uploads/escudos/' . $filename;
    }

    $logo_visitante = '';
    if (isset($_FILES['logo_visitante']) && $_FILES['logo_visitante']['error'] === UPLOAD_ERR_OK) {
        $filename = uniqid('visitante_') . '.webp';
        @move_uploaded_file($_FILES['logo_visitante']['tmp_name'], $uploadDir . $filename);
        $logo_visitante = 'uploads/escudos/' . $filename;
    }

    if (isset($pdo)) {
        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("INSERT INTO jogos (time_mandante, time_visitante, logo_mandante, logo_visitante, odd_1, odd_x, odd_2, data_hora, status, gols_mandante, gols_visitante) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'aberto', 0, 0)");
            $stmt->execute([$time_mandante, $time_visitante, $logo_mandante, $logo_visitante, $odd_1, $odd_x, $odd_2, $data_hora]);
            $novo_jogo_id = $pdo->lastInsertId();

            // Se preencheu o mercado extra, cadastra também
            if (!empty($pergunta_extra) && !empty($opcao_extra) && $odd_extra > 0) {
                $stmtExtra = $pdo->prepare("INSERT INTO mercados_extras (jogo_id, pergunta, opcao, odd, status) VALUES (?, ?, ?, ?, 'aberto')");
                $stmtExtra->execute([$novo_jogo_id, $pergunta_extra, $opcao_extra, $odd_extra]);
            }

            $pdo->commit();
            $_SESSION['mensagem_admin'] = "Jogo e mercado extra cadastrados com sucesso!";
        } catch (Exception $e) {
            $pdo->rollBack();
            $_SESSION['erro_admin'] = "Erro ao cadastrar jogo: " . $e->getMessage();
        }
    }
    header("Location: index.php");
    exit;
}

$depositos = [];
$tem_pendente = false;
if (isset($pdo)) {
    try {
        $stmt = $pdo->query("SELECT * FROM depositos_pix ORDER BY data_hora DESC LIMIT 20");
        $depositos = $stmt->fetchAll();
        foreach ($depositos as $d) {
            if ($d['status'] === 'Pendente') { $tem_pendente = true; }
        }
    } catch (Exception $e) {}
}

$jogos = [];
if (isset($pdo)) {
    try {
        $stmt = $pdo->query("SELECT * FROM jogos ORDER BY data_hora DESC");
        $jogos = $stmt->fetchAll();
    } catch (Exception $e) {}
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Painel Administrativo - ArenaBet</title>
  <meta name="keywords" content="arena apostas esportivas, aposta, odds, futebol, painel admin, lucros">
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    :root { --neon-green: #00FF66; --bg-dark: #07090e; }
    body { background-color: var(--bg-dark); color: #ffffff; font-family: 'Segoe UI', sans-serif; }
    .text-neon { color: var(--neon-green); text-shadow: 0 0 10px rgba(0, 255, 102, 0.35); }
    .bg-neon { background-color: var(--neon-green); color: #000000; }
    .shadow-neon { box-shadow: 0 0 20px rgba(0, 255, 102, 0.35); }
  </style>
</head>
<body class="min-h-screen pb-12">

  <header class="bg-gray-900 border-b border-gray-800 px-4 py-3 mb-6">
    <div class="max-w-6xl mx-auto flex justify-between items-center">
      <div class="flex items-center gap-2">
        <i class="fa-solid fa-gears text-2xl text-neon"></i>
        <span class="text-xl font-extrabold tracking-wider text-white">PAINEL<span class="text-neon">ADMIN</span></span>
      </div>
      <a href="index.php?logout=1" class="px-3 py-2 bg-red-600/20 border border-red-500/40 text-red-400 font-bold text-xs rounded-xl hover:bg-red-600/30 transition">
        <i class="fa-solid fa-right-from-bracket"></i> Sair
      </a>
    </div>
  </header>

  <main class="max-w-6xl mx-auto px-4 space-y-6">
    <?php if ($mensagem): ?><div class="bg-emerald-500/25 border border-emerald-500 text-emerald-200 text-sm p-4 rounded-xl text-center font-bold"><?= $mensagem ?></div><?php endif; ?>
    <?php if ($erro): ?><div class="bg-red-500/25 border border-red-500 text-red-200 text-sm p-4 rounded-xl text-center font-bold"><?= $erro ?></div><?php endif; ?>

    <!-- AVISOS DE DEPÓSITO PIX (Com Acordeon, Alerta Visual Piscando e Botão de Deletar da Tela) -->
    <div class="bg-gray-900 border <?= $tem_pendente ? 'border-neon shadow-neon animate-pulse' : 'border-emerald-500/30' ?> rounded-2xl p-6 shadow-xl transition-all">
      <div class="flex items-center justify-between cursor-pointer" onclick="toggleAcordeonPix()">
        <h3 class="text-lg font-bold text-white flex items-center gap-2">
          <i class="fa-solid fa-money-bill-transfer text-neon"></i> Avisos de Depósito PIX (Clientes)
        </h3>
        <div class="flex items-center gap-3">
          <?php if ($tem_pendente): ?>
            <span class="bg-red-500 text-white text-[10px] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider animate-bounce">
              Novo Pagamento Pendente!
            </span>
          <?php endif; ?>
          <button type="button" class="text-gray-400 hover:text-white text-sm focus:outline-none">
            <i id="iconeAcordeon" class="fa-solid fa-chevron-down transition-transform duration-300"></i>
          </button>
        </div>
      </div>

      <div id="conteudoAcordeonPix" class="mt-4 transition-all duration-300">
        <?php if (empty($depositos)): ?>
          <p class="text-xs text-gray-500 text-center py-4">Nenhum aviso de pagamento.</p>
        <?php else: ?>
          <div class="space-y-3" id="listaDepositosPix">
            <?php foreach ($depositos as $dep): ?>
              <div id="deposito-item-<?= $dep['id'] ?>" class="bg-gray-950 border border-gray-800 rounded-xl p-4 flex justify-between items-center">
                <div>
                  <span class="font-bold text-white text-sm"><?= htmlspecialchars($dep['usuario_nome']) ?></span> (ID: <?= $dep['usuario_id'] ?>)
                  <div class="text-xs text-gray-400"><?= date('d/m/Y H:i', strtotime($dep['data_hora'])) ?></div>
                </div>
                <div class="flex items-center gap-3">
                  <div class="text-neon font-extrabold text-sm">R$ <?= number_format($dep['valor'], 2, ',', '.') ?></div>
                  <?php if ($dep['status'] === 'Pendente'): ?>
                    <a href="index.php?aprovar_pix=<?= $dep['id'] ?>" class="px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white font-bold text-xs rounded-lg animate-pulse">Aprovar</a>
                  <?php else: ?>
                    <span class="text-emerald-400 text-xs font-bold">Aprovado</span>
                  <?php endif; ?>
                  <button type="button" onclick="removerDepositoTela(<?= $dep['id'] ?>)" class="w-8 h-8 bg-gray-800 hover:bg-red-600/40 text-gray-400 hover:text-red-300 rounded-lg flex items-center justify-center transition text-xs" title="Ocultar deste painel">
                    <i class="fa-solid fa-trash-can"></i>
                  </button>
                </div>
              </div>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- GERENCIAR / ENCERRAR JOGOS COM PLACAR REAL -->
    <div class="bg-gray-900 border border-gray-800 rounded-2xl p-6">
      <h3 class="text-lg font-bold text-white mb-4 flex items-center gap-2">
        <i class="fa-solid fa-trophy text-neon"></i> Gerenciar Jogos & Definir Placar / Vencedores
      </h3>
      <?php if (empty($jogos)): ?>
        <p class="text-xs text-gray-500 text-center py-4">Nenhum jogo cadastrado.</p>
      <?php else: ?>
        <div class="space-y-4">
          <?php foreach ($jogos as $j): ?>
            <div class="bg-gray-950 border border-gray-800 rounded-xl p-4 flex flex-col gap-3">
              <div class="flex justify-between items-center text-xs text-gray-400">
                <span>Status: <strong class="<?= $j['status'] === 'aberto' ? 'text-emerald-400' : 'text-red-400' ?> uppercase"><?= $j['status'] ?></strong></span>
                <span>Data: <?= date('d/m/Y H:i', strtotime($j['data_hora'])) ?></span>
              </div>
              
              <div class="flex justify-between items-center font-bold text-sm text-white">
                <span><?= htmlspecialchars($j['time_mandante']) ?></span>
                <span class="text-neon">VS</span>
                <span><?= htmlspecialchars($j['time_visitante']) ?></span>
              </div>

              <?php if ($j['status'] === 'aberto'): ?>
                <form method="POST" class="bg-gray-900 border border-gray-800 rounded-xl p-3 flex flex-col sm:flex-row gap-3 items-center justify-between">
                  <input type="hidden" name="jogo_id" value="<?= $j['id'] ?>">
                  
                  <div class="flex items-center gap-2">
                    <span class="text-xs text-gray-300">Gols Casa:</span>
                    <input type="number" name="gols_mandante" required min="0" value="0" class="w-16 bg-gray-950 border border-gray-800 rounded-lg p-2 text-white font-bold text-center text-sm">
                    <span class="text-xs text-gray-300">Gols Fora:</span>
                    <input type="number" name="gols_visitante" required min="0" value="0" class="w-16 bg-gray-950 border border-gray-800 rounded-lg p-2 text-white font-bold text-center text-sm">
                  </div>

                  <div class="flex items-center gap-2">
                    <select name="vencedor" required class="bg-gray-950 border border-gray-800 rounded-lg p-2 text-xs text-white font-bold">
                      <option value="Casa (1)">Vencedor: Casa (1)</option>
                      <option value="Empate (X)">Vencedor: Empate (X)</option>
                      <option value="Fora (2)">Vencedor: Fora (2)</option>
                    </select>
                    <button type="submit" name="encerrar_partida" onclick="return confirm('Encerrar jogo com este placar e pagar prêmios?')" class="px-4 py-2 bg-neon text-black font-extrabold text-xs rounded-lg hover:bg-emerald-400 transition">
                      ENCERRAR & PAGAR
                    </button>
                  </div>
                </form>
              <?php else: ?>
                <div class="text-xs text-gray-400 bg-gray-900 p-2 rounded-lg text-center">
                  Placar Final Registrado: <strong class="text-neon"><?= $j['gols_mandante'] ?> x <?= $j['gols_visitante'] ?></strong> (Partida Encerrada)
                </div>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>

    <!-- CADASTRAR NOVO JOGO + MERCADO EXTRA (QUEM VAI FAZER O GOL) -->
    <div class="bg-gray-900 border border-gray-800 rounded-2xl p-6">
      <h3 class="text-lg font-bold text-white mb-4 flex items-center gap-2">
        <i class="fa-solid fa-circle-plus text-neon"></i> Cadastrar Novo Jogo, Odds e Mercado Extra
      </h3>
      <form method="POST" enctype="multipart/form-data" class="space-y-4">
        <input type="hidden" name="cadastrar_jogo" value="1">
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div class="bg-gray-950 p-4 rounded-xl border border-gray-800 space-y-3">
            <h4 class="text-xs font-bold text-gray-400 uppercase">Equipe da Casa (Mandante)</h4>
            <input type="text" name="time_mandante" required class="w-full bg-gray-900 border border-gray-800 rounded-lg p-2.5 text-white text-sm" placeholder="Ex: Cruzeiro">
            <input type="file" name="logo_mandante" accept="image/*" class="w-full text-xs text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:bg-emerald-500/10 file:text-neon">
          </div>
          <div class="bg-gray-950 p-4 rounded-xl border border-gray-800 space-y-3">
            <h4 class="text-xs font-bold text-gray-400 uppercase">Equipe Visitante</h4>
            <input type="text" name="time_visitante" required class="w-full bg-gray-900 border border-gray-800 rounded-lg p-2.5 text-white text-sm" placeholder="Ex: Bahia">
            <input type="file" name="logo_visitante" accept="image/*" class="w-full text-xs text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:bg-emerald-500/10 file:text-neon">
          </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-4 gap-4 bg-gray-950 p-4 rounded-xl border border-gray-800">
          <div><label class="block text-xs text-gray-400 mb-1">Odd Casa (1)</label><input type="number" step="0.01" name="odd_1" value="2.00" required class="w-full bg-gray-900 border border-gray-800 rounded-lg p-2.5 text-white font-bold text-sm"></div>
          <div><label class="block text-xs text-gray-400 mb-1">Odd Empate (X)</label><input type="number" step="0.01" name="odd_x" value="3.20" required class="w-full bg-gray-900 border border-gray-800 rounded-lg p-2.5 text-white font-bold text-sm"></div>
          <div><label class="block text-xs text-gray-400 mb-1">Odd Fora (2)</label><input type="number" step="0.01" name="odd_2" value="3.50" required class="w-full bg-gray-900 border border-gray-800 rounded-lg p-2.5 text-white font-bold text-sm"></div>
          <div><label class="block text-xs text-gray-400 mb-1">Data e Hora</label><input type="datetime-local" name="data_hora" required class="w-full bg-gray-900 border border-gray-800 rounded-lg p-2 text-white text-xs h-[42px]"></div>
        </div>

        <!-- SEÇÃO DE PALPITE EXTRA: QUEM VAI FAZER O GOL -->
        <div class="bg-gray-950 p-4 rounded-xl border border-emerald-500/30 space-y-3">
          <h4 class="text-xs font-bold text-neon uppercase flex items-center gap-1.5">
            <i class="fa-solid fa-star"></i> Mercado Extra (Opcional - Ex: Quem vai fazer o gol?)
          </h4>
          <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label class="block text-[10px] text-gray-400 mb-1">Pergunta do Mercado</label>
              <input type="text" name="pergunta_extra" value="Quem vai fazer o gol?" class="w-full bg-gray-900 border border-gray-800 rounded-lg p-2 text-white text-xs" placeholder="Ex: Quem vai fazer o gol?">
            </div>
            <div>
              <label class="block text-[10px] text-gray-400 mb-1">Nome do Jogador / Opção</label>
              <input type="text" name="opcao_extra" class="w-full bg-gray-900 border border-gray-800 rounded-lg p-2 text-white text-xs" placeholder="Ex: Kaio Jorge (Cruzeiro)">
            </div>
            <div>
              <label class="block text-[10px] text-gray-400 mb-1">Odd do Jogador</label>
              <input type="number" step="0.01" name="odd_extra" value="2.50" class="w-full bg-gray-900 border border-gray-800 rounded-lg p-2 text-white font-bold text-xs">
            </div>
          </div>
        </div>

        <button type="submit" class="w-full bg-neon font-extrabold py-3 rounded-xl text-black hover:bg-emerald-400 transition">CADASTRAR JOGO E MERCADO EXTRA</button>
      </form>
    </div>
  </main>

  <script>
    document.addEventListener("DOMContentLoaded", function() {
      const ocultos = JSON.parse(localStorage.getItem('depositos_ocultos') || '[]');
      ocultos.forEach(id => {
        const el = document.getElementById('deposito-item-' + id);
        if (el) el.style.display = 'none';
      });

      const acordeonAberto = localStorage.getItem('acordeon_pix_aberto');
      if (acordeonAberto === 'false') {
        const conteudo = document.getElementById('conteudoAcordeonPix');
        const icone = document.getElementById('iconeAcordeon');
        if (conteudo && icone) {
          conteudo.style.display = 'none';
          icone.style.transform = 'rotate(-90deg)';
        }
      }
    });

    function toggleAcordeonPix() {
      const conteudo = document.getElementById('conteudoAcordeonPix');
      const icone = document.getElementById('iconeAcordeon');
      if (conteudo.style.display === 'none') {
        conteudo.style.display = 'block';
        icone.style.transform = 'rotate(0deg)';
        localStorage.setItem('acordeon_pix_aberto', 'true');
      } else {
        conteudo.style.display = 'none';
        icone.style.transform = 'rotate(-90deg)';
        localStorage.setItem('acordeon_pix_aberto', 'false');
      }
    }

    function removerDepositoTela(id) {
      if (confirm("Deseja remover este aviso apenas da sua tela? O registro continuará salvo no banco de dados.")) {
        const el = document.getElementById('deposito-item-' + id);
        if (el) {
          el.style.transition = 'all 0.3s ease';
          el.style.opacity = '0';
          setTimeout(() => el.remove(), 300);
        }

        let ocultos = JSON.parse(localStorage.getItem('depositos_ocultos') || '[]');
        if (!ocultos.includes(id)) {
          ocultos.push(id);
          localStorage.setItem('depositos_ocultos', JSON.stringify(ocultos));
        }
      }
    }
  </script>
</body>
</html>