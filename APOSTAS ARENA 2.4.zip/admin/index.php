<?php
@include_once '../conexao.php';
session_start();

$admin_user = 'baltazar';
$admin_pass = '02579100';
$erro_login = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['fazer_login'])) {
    $u = $_POST['usuario'] ?? '';
    $s = $_POST['senha'] ?? '';
    if ($u === $admin_user && $s === $admin_pass) {
        $_SESSION['admin_logado'] = true;
        header("Location: index.php");
        exit;
    } else {
        $erro_login = "Usuário ou senha incorretos!";
    }
}

if (isset($_GET['logout'])) {
    unset($_SESSION['admin_logado']);
    header("Location: index.php");
    exit;
}

if (!isset($_SESSION['admin_logado']) || $_SESSION['admin_logado'] !== true):
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Administrativo - ArenaBet</title>
  <meta name="keywords" content="arena apostas esportivas, aposta, odds, futebol, painel admin, lucros">
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    :root { --neon-green: #00FF66; --bg-dark: #07090e; }
    body { background-color: var(--bg-dark); color: #fff; font-family: 'Segoe UI', sans-serif; }
    .text-neon { color: var(--neon-green); text-shadow: 0 0 10px rgba(0, 255, 102, 0.35); }
    .bg-neon { background-color: var(--neon-green); color: #000; }
  </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4">
  <div class="bg-gray-900 border border-emerald-500/40 rounded-2xl w-full max-w-md p-8 shadow-2xl">
    <div class="text-center mb-6">
      <i class="fa-solid fa-lock text-3xl text-neon mb-2"></i>
      <h3 class="text-2xl font-extrabold text-white">Painel Restrito</h3>
      <p class="text-xs text-gray-400">Identifique-se para acessar o administrador</p>
    </div>
    <?php if ($erro_login): ?>
      <div class="bg-red-500/20 border border-red-500/50 text-red-300 text-xs p-3 rounded-lg mb-4 text-center"><?= $erro_login ?></div>
    <?php endif; ?>
    <form method="POST" class="space-y-4">
      <input type="hidden" name="fazer_login" value="1">
      <div>
        <label class="block text-xs font-medium text-gray-300 mb-1">Usuário</label>
        <input type="text" name="usuario" required class="w-full bg-gray-950 border border-gray-800 rounded-lg p-3 text-white focus:border-emerald-500 focus:outline-none text-sm">
      </div>
      <div>
        <label class="block text-xs font-medium text-gray-300 mb-1">Senha</label>
        <input type="password" name="senha" required class="w-full bg-gray-950 border border-gray-800 rounded-lg p-3 text-white focus:border-emerald-500 focus:outline-none text-sm">
      </div>
      <button type="submit" class="w-full bg-neon font-bold py-3 rounded-lg hover:bg-emerald-400 transition shadow-lg">ENTRAR NO PAINEL</button>
    </form>
    <div class="text-center mt-4"><a href="../index.php" class="text-xs text-gray-500 hover:text-gray-300"><i class="fa-solid fa-arrow-left"></i> Voltar ao site</a></div>
  </div>
</body>
</html>
<?php 
exit;
endif; 

$mensagem = $_SESSION['mensagem_admin'] ?? '';
unset($_SESSION['mensagem_admin']);

$erro = $_SESSION['erro_admin'] ?? '';
unset($_SESSION['erro_admin']);

// Garante tabelas e colunas necessárias no banco de dados de forma totalmente segura
if (isset($pdo)) {
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS `mercados_extras` (
          `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
          `jogo_id` INT(11) NOT NULL,
          `pergunta` VARCHAR(255) NOT NULL,
          `opcao` VARCHAR(150) NOT NULL,
          `odd` DECIMAL(5,2) NOT NULL DEFAULT '2.00',
          `status` ENUM('aberto', 'encerrado') DEFAULT 'aberto'
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
    } catch (Exception $e) {}

    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS `saques_pix` (
          `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
          `usuario_id` INT(11) NOT NULL,
          `usuario_nome` VARCHAR(100) NOT NULL,
          `email` VARCHAR(100) NOT NULL,
          `banco` VARCHAR(100) NOT NULL,
          `chave_pix` VARCHAR(150) NOT NULL,
          `valor` DECIMAL(10,2) NOT NULL,
          `status` VARCHAR(50) DEFAULT 'Pendente',
          `data_hora` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
    } catch (Exception $e) {}

    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS `banners` (
          `id` INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
          `titulo` varchar(150) NOT NULL,
          `link` varchar(255) DEFAULT NULL,
          `imagem` varchar(255) NOT NULL,
          `status` enum('ativo','inativo') DEFAULT 'ativo',
          `criado_em` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
    } catch (Exception $e) {}

    try {
        $pdo->exec("ALTER TABLE jogos ADD COLUMN categoria VARCHAR(100) DEFAULT 'Brasileirão'");
    } catch (Exception $e) {}

    try {
        $pdo->exec("ALTER TABLE jogos ADD COLUMN super_odd TINYINT(1) DEFAULT 0");
    } catch (Exception $e) {}

    try {
        $pdo->exec("ALTER TABLE jogos ADD COLUMN oculto_admin TINYINT(1) DEFAULT 0");
    } catch (Exception $e) {}

    try {
        $pdo->exec("ALTER TABLE depositos_pix ADD COLUMN oculto_admin TINYINT(1) DEFAULT 0");
    } catch (Exception $e) {}

    try {
        $pdo->exec("ALTER TABLE saques_pix ADD COLUMN oculto_admin TINYINT(1) DEFAULT 0");
    } catch (Exception $e) {}
}

// OCULTAR JOGO DO PAINEL ADMIN (Mantém no banco para landing page)
if (isset($_GET['ocultar_jogo']) && isset($pdo)) {
    $jogo_id = intval($_GET['ocultar_jogo']);
    try {
        $pdo->prepare("UPDATE jogos SET oculto_admin = 1 WHERE id = ?")->execute([$jogo_id]);
        $_SESSION['mensagem_admin'] = "Jogo ocultado do painel com sucesso! (Continuará salvo no banco de dados)";
    } catch (Exception $e) {
        $_SESSION['erro_admin'] = "Erro ao ocultar jogo: " . $e->getMessage();
    }
    header("Location: index.php");
    exit;
}

// OCULTAR DEPÓSITO DO PAINEL ADMIN
if (isset($_GET['ocultar_deposito']) && isset($pdo)) {
    $dep_id = intval($_GET['ocultar_deposito']);
    try {
        $pdo->prepare("UPDATE depositos_pix SET oculto_admin = 1 WHERE id = ?")->execute([$dep_id]);
        $_SESSION['mensagem_admin'] = "Depósito ocultado do painel com sucesso! (Salvo no banco)";
    } catch (Exception $e) {
        $_SESSION['erro_admin'] = "Erro ao ocultar depósito: " . $e->getMessage();
    }
    header("Location: index.php");
    exit;
}

// OCULTAR SAQUE DO PAINEL ADMIN
if (isset($_GET['ocultar_saque']) && isset($pdo)) {
    $saq_id = intval($_GET['ocultar_saque']);
    try {
        $pdo->prepare("UPDATE saques_pix SET oculto_admin = 1 WHERE id = ?")->execute([$saq_id]);
        $_SESSION['mensagem_admin'] = "Saque ocultado do painel com sucesso! (Salvo no banco)";
    } catch (Exception $e) {
        $_SESSION['erro_admin'] = "Erro ao ocultar saque: " . $e->getMessage();
    }
    header("Location: index.php");
    exit;
}

// Aprovação de Depósito PIX
if (isset($_GET['aprovar_pix']) && isset($pdo)) {
    $deposito_id = intval($_GET['aprovar_pix']);
    try {
        $stmt = $pdo->prepare("SELECT * FROM depositos_pix WHERE id = ? AND status = 'Pendente'");
        $stmt->execute([$deposito_id]);
        $dep = $stmt->fetch();

        if ($dep) {
            $pdo->prepare("UPDATE depositos_pix SET status = 'Aprovado' WHERE id = ?")->execute([$deposito_id]);
            $pdo->prepare("UPDATE usuarios SET saldo = saldo + ? WHERE id = ?")->execute([$dep['valor'], $dep['usuario_id']]);
            $_SESSION['mensagem_admin'] = "Depósito de R$ " . number_format($dep['valor'], 2, ',', '.') . " aprovado e saldo creditado!";
        }
    } catch (Exception $e) {
        $_SESSION['erro_admin'] = "Erro ao aprovar depósito: " . $e->getMessage();
    }
    header("Location: index.php");
    exit;
}

// APROVAÇÃO DE SAQUE PIX
if (isset($_GET['aprovar_saque']) && isset($pdo)) {
    $saque_id = intval($_GET['aprovar_saque']);
    try {
        $stmt = $pdo->prepare("UPDATE saques_pix SET status = 'Aprovado' WHERE id = ? AND status = 'Pendente'");
        $stmt->execute([$saque_id]);
        $_SESSION['mensagem_admin'] = "Saque aprovado com sucesso!";
    } catch (Exception $e) {
        $_SESSION['erro_admin'] = "Erro ao aprovar saque: " . $e->getMessage();
    }
    header("Location: index.php");
    exit;
}

// RECUSA DE SAQUE PIX (Estorna o valor automaticamente para o saldo do cliente)
if (isset($_GET['recusar_saque']) && isset($pdo)) {
    $saque_id = intval($_GET['recusar_saque']);
    try {
        $stmt = $pdo->prepare("SELECT * FROM saques_pix WHERE id = ? AND status = 'Pendente'");
        $stmt->execute([$saque_id]);
        $sq = $stmt->fetch();

        if ($sq) {
            $pdo->beginTransaction();
            $pdo->prepare("UPDATE saques_pix SET status = 'Recusado' WHERE id = ?")->execute([$saque_id]);
            $pdo->prepare("UPDATE usuarios SET saldo = saldo + ? WHERE id = ?")->execute([$sq['valor'], $sq['usuario_id']]);
            $pdo->commit();
            $_SESSION['mensagem_admin'] = "Saque recusado e R$ " . number_format($sq['valor'], 2, ',', '.') . " estornados com sucesso para o saldo do cliente!";
        }
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['erro_admin'] = "Erro ao recusar saque: " . $e->getMessage();
    }
    header("Location: index.php");
    exit;
}

// CADASTRO DE BANNER
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cadastrar_banner'])) {
    $titulo = trim($_POST['titulo_banner'] ?? '');
    $link = trim($_POST['link_banner'] ?? '');
    $uploadDir = '../uploads/banners/';
    if (!is_dir($uploadDir)) { @mkdir($uploadDir, 0755, true); }

    if (isset($_FILES['imagem_banner']) && $_FILES['imagem_banner']['error'] === UPLOAD_ERR_OK) {
        $filename = uniqid('banner_') . '.webp';
        @move_uploaded_file($_FILES['imagem_banner']['tmp_name'], $uploadDir . $filename);
        $imagemPath = 'uploads/banners/' . $filename;

        if (isset($pdo)) {
            try {
                $stmt = $pdo->prepare("INSERT INTO banners (titulo, link, imagem, status) VALUES (?, ?, ?, 'ativo')");
                $stmt->execute([$titulo, $link, $imagemPath]);
                $_SESSION['mensagem_admin'] = "Banner cadastrado com sucesso!";
            } catch (Exception $e) {
                $_SESSION['erro_admin'] = "Erro ao cadastrar banner: " . $e->getMessage();
            }
        }
    } else {
        $_SESSION['erro_admin'] = "Selecione uma imagem válida para o banner.";
    }
    header("Location: index.php");
    exit;
}

// EXCLUIR BANNER
if (isset($_GET['excluir_banner']) && isset($pdo)) {
    $banner_id = intval($_GET['excluir_banner']);
    try {
        $stmtB = $pdo->prepare("SELECT imagem FROM banners WHERE id = ?");
        $stmtB->execute([$banner_id]);
        $b = $stmtB->fetch();
        if ($b && !empty($b['imagem']) && file_exists('../' . $b['imagem'])) {
            @unlink('../' . $b['imagem']);
        }
        $pdo->prepare("DELETE FROM banners WHERE id = ?")->execute([$banner_id]);
        $_SESSION['mensagem_admin'] = "Banner excluído com sucesso!";
    } catch (Exception $e) {
        $_SESSION['erro_admin'] = "Erro ao excluir banner: " . $e->getMessage();
    }
    header("Location: index.php");
    exit;
}

// Encerramento de Jogo com Placar Real, Vencedor e Mercados Extras Premiados
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['encerrar_partida'])) {
    $jogo_id = intval($_POST['jogo_id'] ?? 0);
    $gols_mandante = intval($_POST['gols_mandante'] ?? 0);
    $gols_visitante = intval($_POST['gols_visitante'] ?? 0);
    $vencedor = trim($_POST['vencedor'] ?? '');
    $mercados_vencedores = $_POST['mercados_vencedores'] ?? [];

    try {
        $pdo->beginTransaction();

        $stmt = $pdo->prepare("UPDATE jogos SET status = 'encerrado', gols_mandante = ?, gols_visitante = ? WHERE id = ?");
        $stmt->execute([$gols_mandante, $gols_visitante, $jogo_id]);

        $pdo->prepare("UPDATE mercados_extras SET status = 'encerrado' WHERE jogo_id = ?")->execute([$jogo_id]);

        $stmt = $pdo->prepare("SELECT * FROM apostas WHERE jogo_id = ? AND status = 'Pendente'");
        $stmt->execute([$jogo_id]);
        $apostas = $stmt->fetchAll();

        $total_pagamentos = 0;
        foreach ($apostas as $aposta) {
            $tipo = $aposta['tipo_aposta'];
            if ($tipo === $vencedor || in_array($tipo, $mercados_vencedores)) {
                $pdo->prepare("UPDATE apostas SET status = 'Ganha' WHERE id = ?")->execute([$aposta['id']]);
                $pdo->prepare("UPDATE usuarios SET saldo = saldo + ? WHERE id = ?")->execute([$aposta['possivel_retorno'], $aposta['usuario_id']]);
                $total_pagamentos++;
            } else {
                $pdo->prepare("UPDATE apostas SET status = 'Perdida' WHERE id = ?")->execute([$aposta['id']]);
            }
        }

        $pdo->commit();
        $_SESSION['mensagem_admin'] = "Jogo encerrado! Placar: $gols_mandante x $gols_visitante. Vencedor: $vencedor. $total_pagamentos apostas premiadas pagas!";
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['erro_admin'] = "Erro ao encerrar jogo: " . $e->getMessage();
    }
    header("Location: index.php");
    exit;
}

// Cadastro de Novo Jogo + Categoria + Super Odd + Mercado Extra
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cadastrar_jogo'])) {
    $time_mandante = $_POST['time_mandante'] ?? '';
    $time_visitante = $_POST['time_visitante'] ?? '';
    $categoria = $_POST['categoria'] ?? 'Brasileirão';
    $super_odd = isset($_POST['super_odd']) ? 1 : 0;
    $odd_1 = floatval($_POST['odd_1'] ?? 1.00);
    $odd_x = floatval($_POST['odd_x'] ?? 1.00);
    $odd_2 = floatval($_POST['odd_2'] ?? 1.00);
    $data_hora = $_POST['data_hora'] ?? date('Y-m-d H:i:s');

    $pergunta_extra = trim($_POST['pergunta_extra'] ?? '');
    $opcao_extra = trim($_POST['opcao_extra'] ?? '');
    $odd_extra = floatval($_POST['odd_extra'] ?? 0.00);

    $uploadDir = '../uploads/escudos/';
    if (!is_dir($uploadDir)) { @mkdir($uploadDir, 0755, true); }

    $logo_mandante = '';
    if (isset($_FILES['logo_mandante']) && $_FILES['logo_mandante']['error'] === UPLOAD_ERR_OK) {
        $filename = uniqid('mandante_') . '.webp';
        @move_uploaded_file($_FILES['logo_mandante']['tmp_name'], $uploadDir . $filename);
        $logo_mandante = 'uploads/escudos/' . $filename;
    }

    $logo_visitante = '';
    if (isset($_FILES['logo_visitante']) && $_FILES['logo_visitante']['error'] === UPLOAD_ERR_OK) {
        $filename = uniqid('visitante_') . '.webp';
        @move_uploaded_file($_FILES['logo_visitante']['tmp_name'], $uploadDir . $filename);
        $logo_visitante = 'uploads/escudos/' . $filename;
    }

    if (isset($pdo)) {
        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("INSERT INTO jogos (time_mandante, time_visitante, logo_mandante, logo_visitante, categoria, super_odd, odd_1, odd_x, odd_2, data_hora, status, gols_mandante, gols_visitante, oculto_admin) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'aberto', 0, 0, 0)");
            $stmt->execute([$time_mandante, $time_visitante, $logo_mandante, $logo_visitante, $categoria, $super_odd, $odd_1, $odd_x, $odd_2, $data_hora]);
            $novo_jogo_id = $pdo->lastInsertId();

            if (!empty($pergunta_extra) && !empty($opcao_extra) && $odd_extra > 0) {
                $stmtExtra = $pdo->prepare("INSERT INTO mercados_extras (jogo_id, pergunta, opcao, odd, status) VALUES (?, ?, ?, ?, 'aberto')");
                $stmtExtra->execute([$novo_jogo_id, $pergunta_extra, $opcao_extra, $odd_extra]);
            }

            $pdo->commit();
            $_SESSION['mensagem_admin'] = "Jogo cadastrado com sucesso!";
        } catch (Exception $e) {
            $pdo->rollBack();
            $_SESSION['erro_admin'] = "Erro ao cadastrar jogo: " . $e->getMessage();
        }
    }
    header("Location: index.php");
    exit;
}

$depositos = [];
$tem_pendente = false;
if (isset($pdo)) {
    try {
        $stmt = $pdo->query("SELECT * FROM depositos_pix WHERE oculto_admin = 0 ORDER BY data_hora DESC LIMIT 20");
        $depositos = $stmt->fetchAll();
        foreach ($depositos as $d) {
            if ($d['status'] === 'Pendente') { $tem_pendente = true; }
        }
    } catch (Exception $e) {}
}

$saques = [];
$tem_saque_pendente = false;
if (isset($pdo)) {
    try {
        $stmtS = $pdo->query("SELECT * FROM saques_pix WHERE oculto_admin = 0 ORDER BY data_hora DESC LIMIT 20");
        $saques = $stmtS->fetchAll();
        foreach ($saques as $s) {
            if ($s['status'] === 'Pendente') { $tem_saque_pendente = true; }
        }
    } catch (Exception $e) {}
}

$banners = [];
if (isset($pdo)) {
    try {
        $stmtB = $pdo->query("SELECT * FROM banners ORDER BY id DESC");
        $banners = $stmtB->fetchAll();
    } catch (Exception $e) {}
}

$jogos = [];
if (isset($pdo)) {
    try {
        $stmt = $pdo->query("SELECT * FROM jogos ORDER BY data_hora ASC");
        $jogos = $stmt->fetchAll();
    } catch (Exception $e) {}
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Painel Administrativo - ArenaBet</title>
  <meta name="keywords" content="arena apostas esportivas, aposta, odds, futebol, painel admin, lucros">
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    :root { --neon-green: #00FF66; --bg-dark: #07090e; }
    body { background-color: var(--bg-dark); color: #ffffff; font-family: 'Segoe UI', sans-serif; }
    .text-neon { color: var(--neon-green); text-shadow: 0 0 10px rgba(0, 255, 102, 0.35); }
    .bg-neon { background-color: var(--neon-green); color: #000000; }
    .shadow-neon { box-shadow: 0 0 20px rgba(0, 255, 102, 0.35); }
  </style>
</head>
<body class="min-h-screen pb-12">

  <header class="bg-gray-900 border-b border-gray-800 px-4 py-3 mb-6">
    <div class="max-w-6xl mx-auto flex justify-between items-center">
      <div class="flex items-center gap-2">
        <i class="fa-solid fa-gears text-2xl text-neon"></i>
        <span class="text-xl font-extrabold tracking-wider text-white">PAINEL<span class="text-neon">ADMIN</span></span>
      </div>
      <a href="index.php?logout=1" class="px-3 py-2 bg-red-600/20 border border-red-500/40 text-red-400 font-bold text-xs rounded-xl hover:bg-red-600/30 transition">
        <i class="fa-solid fa-right-from-bracket"></i> Sair
      </a>
    </div>
  </header>

  <main class="max-w-6xl mx-auto px-4 space-y-6">
    <?php if ($mensagem): ?><div class="bg-emerald-500/25 border border-emerald-500 text-emerald-200 text-sm p-4 rounded-xl text-center font-bold"><?= $mensagem ?></div><?php endif; ?>
    <?php if ($erro): ?><div class="bg-red-500/25 border border-red-500 text-red-200 text-sm p-4 rounded-xl text-center font-bold"><?= $erro ?></div><?php endif; ?>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
      <!-- AVISOS DE DEPÓSITO PIX -->
      <div class="bg-gray-900 border <?= $tem_pendente ? 'border-neon shadow-neon animate-pulse' : 'border-emerald-500/30' ?> rounded-2xl p-6 shadow-xl transition-all">
        <div class="flex items-center justify-between cursor-pointer" onclick="toggleAcordeonPix()">
          <h3 class="text-base font-bold text-white flex items-center gap-2">
            <i class="fa-solid fa-money-bill-transfer text-neon"></i> Depósitos PIX
          </h3>
          <div class="flex items-center gap-2">
            <?php if ($tem_pendente): ?>
              <span class="bg-red-500 text-white text-[9px] font-extrabold px-2 py-0.5 rounded-full uppercase tracking-wider animate-bounce">Novo!</span>
            <?php endif; ?>
            <button type="button" class="text-gray-400 hover:text-white text-sm focus:outline-none">
              <i id="iconeAcordeonPix" class="fa-solid fa-chevron-down transition-transform duration-300"></i>
            </button>
          </div>
        </div>

        <div id="conteudoAcordeonPix" class="mt-4 transition-all duration-300">
          <?php if (empty($depositos)): ?>
            <p class="text-xs text-gray-500 text-center py-4">Nenhum depósito registrado.</p>
          <?php else: ?>
            <div class="space-y-3">
              <?php foreach ($depositos as $dep): ?>
                <div class="bg-gray-950 border border-gray-800 rounded-xl p-3 flex justify-between items-center text-xs">
                  <div>
                    <span class="font-bold text-white"><?= htmlspecialchars($dep['usuario_nome']) ?></span> (ID: <?= $dep['usuario_id'] ?>)
                    <div class="text-[10px] text-gray-400"><?= date('d/m/Y H:i', strtotime($dep['data_hora'])) ?></div>
                  </div>
                  <div class="flex items-center gap-2">
                    <div class="text-neon font-extrabold">R$ <?= number_format($dep['valor'], 2, ',', '.') ?></div>
                    <?php if ($dep['status'] === 'Pendente'): ?>
                      <a href="index.php?aprovar_pix=<?= $dep['id'] ?>" class="px-2.5 py-1 bg-red-600 hover:bg-red-500 text-white font-bold rounded-lg animate-pulse">Aprovar</a>
                    <?php else: ?>
                      <span class="text-emerald-400 font-bold">Aprovado</span>
                    <?php endif; ?>
                    <!-- BOTÃO X VERMELHO PARA OCULTAR DEPÓSITO -->
                    <a href="index.php?ocultar_deposito=<?= $dep['id'] ?>" onclick="return confirm('Ocultar este depósito do painel? Ele continuará salvo no banco de dados.')" class="w-6 h-6 bg-red-600/20 hover:bg-red-600 text-red-400 hover:text-white rounded-full flex items-center justify-center transition text-[10px]" title="Ocultar do Painel">
                      <i class="fa-solid fa-xmark"></i>
                    </a>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      </div>

      <!-- SOLICITAÇÕES DE SAQUE DOS CLIENTES -->
      <div class="bg-gray-900 border <?= $tem_saque_pendente ? 'border-red-500 shadow-[0_0_20px_rgba(239,68,68,0.4)] animate-pulse' : 'border-emerald-500/30' ?> rounded-2xl p-6 shadow-xl transition-all">
        <div class="flex items-center justify-between cursor-pointer" onclick="toggleAcordeonSaques()">
          <h3 class="text-base font-bold text-white flex items-center gap-2">
            <i class="fa-solid fa-wallet text-red-400"></i> Solicitações de Saque
          </h3>
          <div class="flex items-center gap-2">
            <?php if ($tem_saque_pendente): ?>
              <span class="bg-red-500 text-white text-[9px] font-extrabold px-2 py-0.5 rounded-full uppercase tracking-wider animate-bounce">Saque Pendente!</span>
            <?php endif; ?>
            <button type="button" class="text-gray-400 hover:text-white text-sm focus:outline-none">
              <i id="iconeAcordeonSaques" class="fa-solid fa-chevron-down transition-transform duration-300"></i>
            </button>
          </div>
        </div>

        <div id="conteudoAcordeonSaques" class="mt-4 transition-all duration-300">
          <?php if (empty($saques)): ?>
            <p class="text-xs text-gray-500 text-center py-4">Nenhum pedido de saque registrado.</p>
          <?php else: ?>
            <div class="space-y-3">
              <?php foreach ($saques as $sq): ?>
                <div class="bg-gray-950 border border-gray-800 rounded-xl p-3 flex flex-col gap-2 text-xs">
                  <div class="flex justify-between items-center">
                    <span class="font-bold text-white"><?= htmlspecialchars($sq['usuario_nome']) ?></span>
                    <span class="text-neon font-extrabold">R$ <?= number_format($sq['valor'], 2, ',', '.') ?></span>
                  </div>
                  <div class="text-[10px] text-gray-400 space-y-0.5">
                    <div>Banco: <strong class="text-white"><?= htmlspecialchars($sq['banco']) ?></strong></div>
                    <div>Chave PIX: <strong class="text-white"><?= htmlspecialchars($sq['chave_pix']) ?></strong></div>
                    <div>E-mail: <?= htmlspecialchars($sq['email']) ?> | Data: <?= date('d/m/Y H:i', strtotime($sq['data_hora'])) ?></div>
                  </div>
                  <div class="flex justify-between items-center pt-2 border-t border-gray-800">
                    <span class="font-bold uppercase text-[10px] <?= $sq['status'] === 'Pendente' ? 'text-yellow-400' : ($sq['status'] === 'Aprovado' ? 'text-emerald-400' : 'text-red-400') ?>">
                      Status: <?= $sq['status'] ?>
                    </span>
                    <div class="flex items-center gap-1.5">
                      <?php if ($sq['status'] === 'Pendente'): ?>
                        <a href="index.php?aprovar_saque=<?= $sq['id'] ?>" onclick="return confirm('Aprovar este pagamento de saque?')" class="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-[10px]">Aprovar</a>
                        <a href="index.php?recusar_saque=<?= $sq['id'] ?>" onclick="return confirm('Recusar e estornar o valor automaticamente para o saldo do cliente?')" class="px-2.5 py-1 bg-red-600 hover:bg-red-500 text-white font-bold rounded-lg text-[10px]">Recusar & Estornar</a>
                      <?php endif; ?>
                      <!-- BOTÃO X VERMELHO PARA OCULTAR SAQUE -->
                      <a href="index.php?ocultar_saque=<?= $sq['id'] ?>" onclick="return confirm('Ocultar este saque do painel? Ele continuará salvo no banco de dados.')" class="w-6 h-6 bg-red-600/20 hover:bg-red-600 text-red-400 hover:text-white rounded-full flex items-center justify-center transition text-[10px]" title="Ocultar do Painel">
                        <i class="fa-solid fa-xmark"></i>
                      </a>
                    </div>
                  </div>
                </div>
              <?php endforeach; ?>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <!-- GERENCIAR BANNERS -->
    <div class="bg-gray-900 border border-gray-800 rounded-2xl p-6 space-y-4">
      <h3 class="text-lg font-bold text-white flex items-center gap-2">
        <i class="fa-solid fa-image text-neon"></i> Gerenciar Banners Promocionais
      </h3>
      <form method="POST" enctype="multipart/form-data" class="bg-gray-950 p-4 rounded-xl border border-gray-800 space-y-3">
        <input type="hidden" name="cadastrar_banner" value="1">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <label class="block text-xs font-medium text-gray-300 mb-1">Título do Banner (Opcional)</label>
            <input type="text" name="titulo_banner" class="w-full bg-gray-900 border border-gray-800 rounded-lg p-2.5 text-white text-xs" placeholder="Ex: Promoção Especial">
          </div>
          <div>
            <label class="block text-xs font-medium text-gray-300 mb-1">Link de Direcionamento (Opcional)</label>
            <input type="text" name="link_banner" class="w-full bg-gray-900 border border-gray-800 rounded-lg p-2.5 text-white text-xs" placeholder="Ex: https://...">
          </div>
        </div>
        <div>
          <label class="block text-xs font-medium text-gray-300 mb-1">Imagem do Banner</label>
          <input type="file" name="imagem_banner" accept="image/*" required class="w-full text-xs text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:bg-emerald-500/10 file:text-neon">
        </div>
        <button type="submit" class="bg-neon font-bold px-4 py-2.5 rounded-lg text-black hover:bg-emerald-400 transition text-xs">CADASTRAR BANNER</button>
      </form>

      <?php if (!empty($banners)): ?>
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          <?php foreach ($banners as $ban): ?>
            <div class="bg-gray-950 border border-gray-800 rounded-xl p-3 space-y-2 relative">
              <img src="../<?= htmlspecialchars($ban['imagem']) ?>" class="w-full h-28 object-cover rounded-lg border border-gray-800">
              <div class="flex justify-between items-center text-xs">
                <span class="text-gray-300 font-bold truncate"><?= htmlspecialchars($ban['titulo'] ?: 'Banner #' . $ban['id']) ?></span>
                <a href="index.php?excluir_banner=<?= $ban['id'] ?>" onclick="return confirm('Deseja excluir este banner?')" class="text-red-400 hover:text-red-300 text-xs" title="Excluir"><i class="fa-solid fa-trash-can"></i></a>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>

    <!-- GERENCIAR / ENCERRAR JOGOS -->
    <div class="bg-gray-900 border border-gray-800 rounded-2xl p-6">
      <h3 class="text-lg font-bold text-white mb-4 flex items-center gap-2">
        <i class="fa-solid fa-trophy text-neon"></i> Gerenciar Jogos & Definir Placar / Vencedores
      </h3>
      <?php 
      // Filtra para exibir apenas os jogos que não foram ocultados no admin
      $jogos_visiveis = array_filter($jogos, function($j) {
          return !isset($j['oculto_admin']) || intval($j['oculto_admin']) !== 1;
      });
      if (empty($jogos_visiveis)): 
      ?>
        <p class="text-xs text-gray-500 text-center py-4">Nenhum jogo ativo no painel.</p>
      <?php else: ?>
        <div class="space-y-4">
          <?php foreach ($jogos_visiveis as $j): ?>
            <div class="bg-gray-950 border border-gray-800 rounded-xl p-4 flex flex-col gap-3">
              <div class="flex justify-between items-center text-xs text-gray-400">
                <span class="text-emerald-400 font-bold"><i class="fa-solid fa-trophy mr-1"></i> <?= htmlspecialchars($j['categoria'] ?? 'Brasileirão') ?></span>
                <span>Status: <strong class="<?= $j['status'] === 'aberto' ? 'text-emerald-400' : 'text-red-400' ?> uppercase"><?= $j['status'] ?></strong> | Data: <?= date('d/m/Y H:i', strtotime($j['data_hora'])) ?></span>
              </div>
              
              <div class="flex justify-between items-center font-bold text-sm text-white">
                <span><?= htmlspecialchars($j['time_mandante']) ?></span>
                <span class="text-neon">VS</span>
                <span><?= htmlspecialchars($j['time_visitante']) ?></span>
              </div>

              <?php if ($j['status'] === 'aberto'): ?>
                <form method="POST" class="bg-gray-900 border border-gray-800 rounded-xl p-3 flex flex-col gap-3">
                  <input type="hidden" name="jogo_id" value="<?= $j['id'] ?>">
                  
                  <div class="flex flex-col sm:flex-row gap-3 items-center justify-between">
                    <div class="flex items-center gap-2">
                      <span class="text-xs text-gray-300">Gols Casa:</span>
                      <input type="number" name="gols_mandante" required min="0" value="0" class="w-16 bg-gray-950 border border-gray-800 rounded-lg p-2 text-white font-bold text-center text-sm">
                      <span class="text-xs text-gray-300">Gols Fora:</span>
                      <input type="number" name="gols_visitante" required min="0" value="0" class="w-16 bg-gray-950 border border-gray-800 rounded-lg p-2 text-white font-bold text-center text-sm">
                    </div>

                    <div class="flex items-center gap-2">
                      <select name="vencedor" required class="bg-gray-950 border border-gray-800 rounded-lg p-2 text-xs text-white font-bold">
                        <option value="Casa (1)">Vencedor: Casa (1)</option>
                        <option value="Empate (X)">Vencedor: Empate (X)</option>
                        <option value="Fora (2)">Vencedor: Fora (2)</option>
                      </select>
                      <button type="submit" name="encerrar_partida" onclick="return confirm('Encerrar jogo com este placar e pagar prêmios?')" class="px-4 py-2 bg-neon text-black font-extrabold text-xs rounded-lg hover:bg-emerald-400 transition">
                        ENCERRAR & PAGAR
                      </button>
                    </div>
                  </div>

                  <?php
                  $stmtExtra = $pdo->prepare("SELECT * FROM mercados_extras WHERE jogo_id = ?");
                  $stmtExtra->execute([$j['id']]);
                  $extras_jogo = $stmtExtra->fetchAll();
                  if (!empty($extras_jogo)):
                  ?>
                    <div class="bg-gray-950 border border-emerald-500/30 rounded-lg p-3 space-y-2">
                      <span class="text-xs font-bold text-neon uppercase flex items-center gap-1">
                        <i class="fa-solid fa-star"></i> Mercados Extras / Odds Especiais (Marque os que aconteceram):
                      </span>
                      <div class="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        <?php foreach ($extras_jogo as $ex): ?>
                          <label class="flex items-center gap-2 text-xs text-gray-300 bg-gray-900 p-2 rounded-lg border border-gray-800 cursor-pointer hover:border-emerald-500/50 transition">
                            <input type="checkbox" name="mercados_vencedores[]" value="<?= htmlspecialchars($ex['opcao']) ?>" class="accent-emerald-400 w-4 h-4">
                            <div>
                              <strong class="text-white"><?= htmlspecialchars($ex['opcao']) ?></strong> 
                              <span class="text-gray-400">(Odd: <?= number_format($ex['odd'], 2, ',', '.') ?>)</span>
                              <div class="text-[10px] text-gray-500"><?= htmlspecialchars($ex['pergunta']) ?></div>
                            </div>
                          </label>
                        <?php endforeach; ?>
                      </div>
                    </div>
                  <?php endif; ?>
                </form>
              <?php else: ?>
                <!-- JOGO ENCERRADO COM BOTÃO DE OCULTAR DO PAINEL -->
                <div class="flex flex-col sm:flex-row justify-between items-center gap-3 bg-gray-900 p-3 rounded-lg text-xs">
                  <div class="text-gray-400 text-center sm:text-left">
                    Placar Final Registrado: <strong class="text-neon"><?= $j['gols_mandante'] ?> x <?= $j['gols_visitante'] ?></strong> (Partida Encerrada)
                  </div>
                  <a href="index.php?ocultar_jogo=<?= $j['id'] ?>" onclick="return confirm('Ocultar este jogo do painel admin? Ele continuará salvo no banco de dados.')" class="px-3 py-1.5 bg-gray-800 hover:bg-gray-700 text-gray-300 font-bold rounded-lg text-[10px] transition flex items-center gap-1.5 whitespace-nowrap">
                    <i class="fa-solid fa-eye-slash text-neon"></i> Ocultar do Painel
                  </a>
                </div>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>

    <!-- CADASTRAR NOVO JOGO COM SELEÇÃO DE CATEGORIA E SUPER ODD -->
    <div class="bg-gray-900 border border-gray-800 rounded-2xl p-6">
      <h3 class="text-lg font-bold text-white mb-4 flex items-center gap-2">
        <i class="fa-solid fa-circle-plus text-neon"></i> Cadastrar Novo Jogo, Categoria e Super Odd
      </h3>
      <form method="POST" enctype="multipart/form-data" class="space-y-4">
        <input type="hidden" name="cadastrar_jogo" value="1">
        
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div class="bg-gray-950 p-4 rounded-xl border border-gray-800">
            <label class="block text-xs font-bold text-gray-300 uppercase mb-2"><i class="fa-solid fa-trophy text-neon mr-1"></i> Categoria / Campeonato</label>
            <select name="categoria" required class="w-full bg-gray-900 border border-gray-800 rounded-lg p-3 text-white text-sm font-bold focus:border-emerald-500 focus:outline-none">
              <option value="Brasileirão">Brasileirão</option>
              <option value="Copa do Brasil">Copa do Brasil</option>
              <option value="Libertadores">Libertadores</option>
            </select>
          </div>

          <!-- BOTÃO / CHECKBOX DE SUPER ODD -->
          <div class="bg-gray-950 p-4 rounded-xl border border-emerald-500/40 flex items-center justify-between">
            <div>
              <div class="text-xs font-bold text-neon uppercase flex items-center gap-1"><i class="fa-solid fa-bolt"></i> Destacar como Super Odd?</div>
              <div class="text-[10px] text-gray-400">O jogo ficará com borda neon pulsante no painel do cliente.</div>
            </div>
            <label class="relative inline-flex items-center cursor-pointer">
              <input type="checkbox" name="super_odd" value="1" class="sr-only peer">
              <div class="w-11 h-6 bg-gray-900 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-500 border border-gray-700"></div>
            </label>
          </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div class="bg-gray-950 p-4 rounded-xl border border-gray-800 space-y-3">
            <h4 class="text-xs font-bold text-gray-400 uppercase">Equipe da Casa (Mandante)</h4>
            <input type="text" name="time_mandante" required class="w-full bg-gray-900 border border-gray-800 rounded-lg p-2.5 text-white text-sm" placeholder="Ex: Cruzeiro">
            <input type="file" name="logo_mandante" accept="image/*" class="w-full text-xs text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:bg-emerald-500/10 file:text-neon">
          </div>
          <div class="bg-gray-950 p-4 rounded-xl border border-gray-800 space-y-3">
            <h4 class="text-xs font-bold text-gray-400 uppercase">Equipe Visitante</h4>
            <input type="text" name="time_visitante" required class="w-full bg-gray-900 border border-gray-800 rounded-lg p-2.5 text-white text-sm" placeholder="Ex: Bahia">
            <input type="file" name="logo_visitante" accept="image/*" class="w-full text-xs text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:bg-emerald-500/10 file:text-neon">
          </div>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-4 gap-4 bg-gray-950 p-4 rounded-xl border border-gray-800">
          <div><label class="block text-xs text-gray-400 mb-1">Odd Casa (1)</label><input type="number" step="0.01" name="odd_1" value="2.00" required class="w-full bg-gray-900 border border-gray-800 rounded-lg p-2.5 text-white font-bold text-sm"></div>
          <div><label class="block text-xs text-gray-400 mb-1">Odd Empate (X)</label><input type="number" step="0.01" name="odd_x" value="3.20" required class="w-full bg-gray-900 border border-gray-800 rounded-lg p-2.5 text-white font-bold text-sm"></div>
          <div><label class="block text-xs text-gray-400 mb-1">Odd Fora (2)</label><input type="number" step="0.01" name="odd_2" value="3.50" required class="w-full bg-gray-900 border border-gray-800 rounded-lg p-2.5 text-white font-bold text-sm"></div>
          <div><label class="block text-xs text-gray-400 mb-1">Data e Hora</label><input type="datetime-local" name="data_hora" required class="w-full bg-gray-900 border border-gray-800 rounded-lg p-2 text-white text-xs h-[42px]"></div>
        </div>

        <div class="bg-gray-950 p-4 rounded-xl border border-emerald-500/30 space-y-3">
          <h4 class="text-xs font-bold text-neon uppercase flex items-center gap-1.5">
            <i class="fa-solid fa-star"></i> Mercado Extra (Opcional - Ex: Quem vai fazer o gol?)
          </h4>
          <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label class="block text-[10px] text-gray-400 mb-1">Pergunta do Mercado</label>
              <input type="text" name="pergunta_extra" value="Quem vai fazer o gol?" class="w-full bg-gray-900 border border-gray-800 rounded-lg p-2 text-white text-xs" placeholder="Ex: Quem vai fazer o gol?">
            </div>
            <div>
              <label class="block text-[10px] text-gray-400 mb-1">Nome do Jogador / Opção</label>
              <input type="text" name="opcao_extra" class="w-full bg-gray-900 border border-gray-800 rounded-lg p-2 text-white text-xs" placeholder="Ex: Caio Jorge (Cruzeiro)">
            </div>
            <div>
              <label class="block text-[10px] text-gray-400 mb-1">Odd do Jogador</label>
              <input type="number" step="0.01" name="odd_extra" value="2.50" class="w-full bg-gray-900 border border-gray-800 rounded-lg p-2 text-white font-bold text-xs">
            </div>
          </div>
        </div>

        <button type="submit" class="w-full bg-neon font-extrabold py-3 rounded-xl text-black hover:bg-emerald-400 transition">CADASTRAR JOGO E SUPER ODD</button>
      </form>
    </div>
  </main>

  <script>
    function toggleAcordeonPix() {
      const conteudo = document.getElementById('conteudoAcordeonPix');
      const icone = document.getElementById('iconeAcordeonPix');
      if (conteudo.style.display === 'none') {
        conteudo.style.display = 'block';
        icone.style.transform = 'rotate(0deg)';
      } else {
        conteudo.style.display = 'none';
        icone.style.transform = 'rotate(-90deg)';
      }
    }

    function toggleAcordeonSaques() {
      const conteudo = document.getElementById('conteudoAcordeonSaques');
      const icone = document.getElementById('iconeAcordeonSaques');
      if (conteudo.style.display === 'none') {
        conteudo.style.display = 'block';
        icone.style.transform = 'rotate(0deg)';
      } else {
        conteudo.style.display = 'none';
        icone.style.transform = 'rotate(-90deg)';
      }
    }
  </script>
</body>
</html>