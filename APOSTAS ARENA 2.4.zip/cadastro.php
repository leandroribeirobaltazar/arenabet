<?php
require_once 'conexao.php';
session_start();

$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $senha_texto = $_POST['senha'] ?? '';

    if (!empty($nome) && !empty($email) && !empty($senha_texto)) {
        $senha = password_hash($senha_texto, PASSWORD_DEFAULT);

        try {
            $stmt = $pdo->prepare("INSERT INTO usuarios (nome, email, senha, saldo) VALUES (?, ?, ?, 0.00)");
            $stmt->execute([$nome, $email, $senha]);
            
            $userId = $pdo->lastInsertId();
            $_SESSION['usuario_id'] = $userId;
            $_SESSION['usuario_nome'] = $nome;
            
            header("Location: cliente/index.php");
            exit;
        } catch (Exception $e) {
            // EXibe o erro técnico exato do MySQL na tela para diagnóstico
            $erro = "Erro SQL: " . $e->getMessage();
        }
    } else {
        $erro = "Por favor, preencha todos os campos.";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cadastro - ArenaBet</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <style>
    :root { --neon-green: #00FF66; --neon-green-glow: rgba(0, 255, 102, 0.35); --bg-dark: #07090e; }
    body { background-color: var(--bg-dark); color: #fff; font-family: 'Segoe UI', sans-serif; }
    .text-neon { color: var(--neon-green); text-shadow: 0 0 10px var(--neon-green-glow); }
    .bg-neon { background-color: var(--neon-green); color: #000; }
  </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4">
  <div class="bg-gray-900 border border-emerald-500/40 rounded-2xl w-full max-w-md p-8 shadow-2xl">
    <div class="text-center mb-6">
      <a href="index.php" class="inline-flex items-center gap-2 mb-2">
        <i class="fa-solid fa-futbol text-3xl text-neon"></i>
      </a>
      <h3 class="text-2xl font-extrabold text-white">Criar Nova Conta</h3>
      <p class="text-xs text-gray-400">Cadastre-se para começar a dar seus palpites</p>
    </div>

    <?php if ($erro): ?>
      <div class="bg-red-500/20 border border-red-500/50 text-red-300 text-xs p-3 rounded-lg mb-4 text-center break-all">
        <?= htmlspecialchars($erro) ?>
      </div>
    <?php endif; ?>

    <form method="POST" class="space-y-4">
      <div>
        <label class="block text-xs font-medium text-gray-300 mb-1">Nome Completo</label>
        <input type="text" name="nome" required class="w-full bg-gray-950 border border-gray-800 rounded-lg p-3 text-white focus:border-emerald-500 focus:outline-none text-sm" placeholder="Seu Nome">
      </div>
      <div>
        <label class="block text-xs font-medium text-gray-300 mb-1">E-mail</label>
        <input type="email" name="email" required class="w-full bg-gray-950 border border-gray-800 rounded-lg p-3 text-white focus:border-emerald-500 focus:outline-none text-sm" placeholder="seuemail@email.com">
      </div>
      <div>
        <label class="block text-xs font-medium text-gray-300 mb-1">Senha</label>
        <input type="password" name="senha" required class="w-full bg-gray-950 border border-gray-800 rounded-lg p-3 text-white focus:border-emerald-500 focus:outline-none text-sm" placeholder="••••••••">
      </div>
      <button type="submit" class="w-full bg-neon font-bold py-3 rounded-lg hover:bg-emerald-400 transition shadow-lg">
        CADASTRAR E ENTRAR
      </button>
    </form>

    <div class="text-center mt-6 text-xs text-gray-400">
      Já tem uma conta? <a href="login.php" class="text-neon font-bold hover:underline">Entrar</a>
    </div>
  </div>
</body>
</html>